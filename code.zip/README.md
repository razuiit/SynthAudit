# SynthAudit 2.0

SynthAudit is an open-source Python package for uncertainty-aware, multi-objective auditing of synthetic tabular data. It reports privacy, statistical fidelity, train-synthetic/test-real utility, fairness preservation, Pareto status, and stochastic rank acceptability while keeping the underlying diagnostics and limitations visible.

The software does **not** issue legal-compliance, anonymity, differential-privacy, causal-validity, or substantive-fairness verdicts.

## Authors

1. Smaria Madni — University of Gujrat
2. Usman Zia — University of Gujrat
3. Abdul Razzaq — Department of Computer Science and Information Systems (CSIS), University of Limerick

## Code Ocean reproducible run

The Capsule entry point is the executable file `run`. A reproducible run:

1. installs the local SynthAudit package without downloading runtime dependencies;
2. runs the software test suite;
3. executes 12 isolated metamorphic replicates;
4. executes the four UCI Adult case-study candidates;
5. aggregates the results and regenerates all figures;
6. tests the regenerated headline claims; and
7. compares key regenerated tables with the frozen reference outputs in `/data/frozen_results`.

All generated artefacts are written to `/results`:

- `/results/results/` — CSV, JSON, and HTML audit outputs;
- `/results/figures/` — regenerated PNG and PDF figures;
- `/results/reproduction.log` — complete execution log; and
- `/results/verification.txt` — frozen-output comparison report.

The Adult source file and its attribution are in `/data`. Frozen reference outputs are supplied under `/data/frozen_results` and `/data/frozen_figures`; they are never treated as newly generated results.

## Local reproduction

From the repository root:

```bash
python -m pip install -r requirements-lock.txt
python -m pip install -e . --no-build-isolation
bash experiments/reproduce_all.sh
```

The default local output directories are `results/` and `figures/`. They can be overridden with:

- `SYNTHAUDIT_DATA_DIR`
- `SYNTHAUDIT_RESULTS_DIR`
- `SYNTHAUDIT_FIGURES_DIR`

## Repository structure

- `src/synthaudit/` — reusable package and command-line interface
- `experiments/` — reproducible study scripts
- `tests/` — unit, integration, and reproduced-claim tests
- `docs/` — API and supplementary methods
- `run` — Code Ocean end-to-end driver
- `requirements-lock.txt` — exact dependency versions

## Archival release

The exact SynthAudit 2.0.0 release is archived at https://doi.org/10.5281/zenodo.21776599.

## Licence

MIT. The UCI Adult dataset remains subject to its own attribution and licence information supplied in `/data/LICENSE-ATTRIBUTION.txt`.
