from __future__ import annotations
import os
from pathlib import Path
import numpy as np
import pandas as pd

results = Path(os.environ.get("SYNTHAUDIT_RESULTS_DIR", "/results/results"))
frozen = Path(os.environ.get("SYNTHAUDIT_FROZEN_RESULTS_DIR", "/data/frozen_results"))

checks = [
    ("metamorphic/metamorphic_selectivity.csv", ["intended_mean_loss", "largest_mean_loss"]),
    ("adult_case/dimension_scores.csv", ["privacy", "fidelity", "downstream_utility", "fairness"]),
    ("adult_case/rank_acceptability.csv", ["first_rank_probability", "expected_rank"]),
]

failures = []
print("SynthAudit frozen-output verification")
for rel, numeric_cols in checks:
    got_path, ref_path = results / rel, frozen / rel
    if not got_path.exists() or not ref_path.exists():
        failures.append(f"missing file: {rel}")
        print(f"FAIL {rel}: generated or frozen file missing")
        continue
    got, ref = pd.read_csv(got_path), pd.read_csv(ref_path)
    common_text = [c for c in got.columns if c in ref.columns and c not in numeric_cols]
    shape_ok = got.shape == ref.shape
    text_ok = shape_ok and all(got[c].astype(str).tolist() == ref[c].astype(str).tolist() for c in common_text)
    num_ok = shape_ok
    max_diff = 0.0
    for c in numeric_cols:
        if c not in got.columns or c not in ref.columns:
            num_ok = False
            continue
        a, b = got[c].to_numpy(float), ref[c].to_numpy(float)
        max_diff = max(max_diff, float(np.nanmax(np.abs(a-b))))
        num_ok = num_ok and bool(np.allclose(a, b, rtol=1e-7, atol=1e-9, equal_nan=True))
    ok = shape_ok and text_ok and num_ok
    print(f"{'PASS' if ok else 'FAIL'} {rel} (maximum checked absolute difference: {max_diff:.3e})")
    if not ok:
        failures.append(rel)

if failures:
    raise SystemExit("Verification failed: " + ", ".join(failures))
print("All headline regenerated outputs agree with the frozen reference release within tolerance.")
