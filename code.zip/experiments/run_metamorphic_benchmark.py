from __future__ import annotations
import sys
from pathlib import Path
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))
sys.path.insert(0, str(ROOT / "experiments"))
from paths import RESULTS_DIR, FIGURES_DIR
from synthaudit import AuditConfig, audit_many
from generators import generate_dgp, metamorphic_variants

OUT = RESULTS_DIR / "metamorphic"
FIG = FIGURES_DIR
OUT.mkdir(parents=True, exist_ok=True)
FIG.mkdir(parents=True, exist_ok=True)

REPEATS = 12
records = []
rank_records = []
for rep in range(REPEATS):
    seed = 100 + rep
    full = generate_dgp(3600, seed)
    train = full.iloc[:2400].reset_index(drop=True)
    test = full.iloc[2400:].reset_index(drop=True)
    variants = metamorphic_variants(train, len(train), seed)
    cfg = AuditConfig(target="income", protected=("sex", "race"),
                      categorical=("education", "occupation", "sex", "race"),
                      numerical=("age", "hours", "debt"),
                      quasi_identifiers=("age", "hours", "education", "occupation", "sex", "race"),
                      positive_label=">50K", seed=seed, max_privacy_rows=450,
                      bootstrap_repeats=50, min_group_size=30)
    bundle = audit_many(train, test, variants, cfg, n_weight_draws=25000)
    for candidate, row in bundle["scores"].iterrows():
        records.append({"replicate": rep, "candidate": candidate, **row.to_dict()})
    rr = bundle["rank_acceptability"].reset_index()
    rr["replicate"] = rep
    rank_records.append(rr)
    print(f"completed replicate {rep + 1}/{REPEATS}")

raw = pd.DataFrame(records)
raw.to_csv(OUT / "metamorphic_raw.csv", index=False)
ranks = pd.concat(rank_records, ignore_index=True)
ranks.to_csv(OUT / "metamorphic_rank_raw.csv", index=False)

dims = ["privacy", "fidelity", "downstream_utility", "fairness"]
summary = raw.groupby("candidate")[dims].agg(["mean", "std", "count"])
summary.to_csv(OUT / "metamorphic_summary.csv")

# Figure 1: module scores with 95% normal-approximation intervals across replicates.
means = raw.groupby("candidate")[dims].mean()
ses = raw.groupby("candidate")[dims].sem()
order = ["Ideal DGP", "Memorising", "Independent marginals", "Bias amplified", "Range corrupted", "Mode collapsed"]
means, ses = means.loc[order], ses.loc[order]
x = np.arange(len(order)); width = 0.19
fig, ax = plt.subplots(figsize=(11, 5.6))
for i, d in enumerate(dims):
    ax.bar(x + (i - 1.5) * width, means[d], width, yerr=1.96 * ses[d], capsize=3, label=d.replace("_", " ").title())
ax.set_xticks(x); ax.set_xticklabels(order, rotation=18, ha="right")
ax.set_ylim(0, 1.05); ax.set_ylabel("Score (higher is better)")
ax.set_title("Metamorphic validation: each injected failure is exposed by its intended audit dimension")
ax.legend(ncol=2, frameon=False); fig.tight_layout()
fig.savefig(FIG / "metamorphic_module_scores.png", dpi=300)
fig.savefig(FIG / "metamorphic_module_scores.pdf")
plt.close(fig)

# Figure 2: diagnostic loss relative to ideal.
loss = means.loc[order[1:]].copy()
for d in dims:
    loss[d] = means.loc["Ideal DGP", d] - loss[d]
fig, ax = plt.subplots(figsize=(8.5, 4.7))
im = ax.imshow(loss[dims].to_numpy(), aspect="auto", vmin=-0.15, vmax=max(0.35, float(loss.max().max())))
ax.set_yticks(np.arange(len(loss.index))); ax.set_yticklabels(loss.index)
ax.set_xticks(np.arange(len(dims))); ax.set_xticklabels([d.replace("_", " ").title() for d in dims], rotation=20, ha="right")
for i in range(loss.shape[0]):
    for j in range(loss.shape[1]):
        ax.text(j, i, f"{loss.iat[i,j]:.2f}", ha="center", va="center")
ax.set_title("Score loss relative to an independent sample from the same data-generating process")
fig.colorbar(im, ax=ax, label="Loss relative to ideal")
fig.tight_layout(); fig.savefig(FIG / "metamorphic_diagnostic_heatmap.png", dpi=300); fig.savefig(FIG / "metamorphic_diagnostic_heatmap.pdf"); plt.close(fig)

# Figure 3: average first-rank acceptability.
rank_summary = ranks.groupby("candidate")["first_rank_probability"].mean().sort_values(ascending=False)
fig, ax = plt.subplots(figsize=(8, 4.5))
ax.bar(rank_summary.index, rank_summary.values)
ax.set_ylim(0, 1); ax.set_ylabel("Probability of rank 1")
ax.set_title("Stochastic rank acceptability under 25,000 random stakeholder weight vectors per replicate")
ax.tick_params(axis="x", rotation=20); fig.tight_layout()
fig.savefig(FIG / "metamorphic_rank_acceptability.png", dpi=300); fig.savefig(FIG / "metamorphic_rank_acceptability.pdf"); plt.close(fig)

print(summary)
