from pathlib import Path
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch
ROOT=Path(__file__).resolve().parents[1]
import sys;sys.path.insert(0,str(ROOT/'experiments'))
from paths import FIGURES_DIR
out=FIGURES_DIR;out.mkdir(parents=True,exist_ok=True)
fig,ax=plt.subplots(figsize=(11,4.3));ax.set_xlim(0,11);ax.set_ylim(0,4.3);ax.axis('off')
def box(x,y,w,h,text,fontsize=10):
 p=FancyBboxPatch((x,y),w,h,boxstyle='round,pad=0.03,rounding_size=0.08',linewidth=1.2,facecolor='white',edgecolor='black');ax.add_patch(p);ax.text(x+w/2,y+h/2,text,ha='center',va='center',fontsize=fontsize);return p
def arrow(x1,y1,x2,y2): ax.add_patch(FancyArrowPatch((x1,y1),(x2,y2),arrowstyle='-|>',mutation_scale=12,linewidth=1.1,color='black'))
box(.2,2.7,1.7,1.0,'Real training\ndata')
box(.2,1.35,1.7,1.0,'Real holdout\ndata')
box(.2,0.0,1.7,1.0,'One or more\nsynthetic datasets')
box(2.5,3.1,1.85,.75,'Privacy audit')
box(2.5,2.15,1.85,.75,'Mixed-type fidelity')
box(2.5,1.2,1.85,.75,'TSTR utility')
box(2.5,.25,1.85,.75,'Fairness drift')
for y in [3.475,2.525,1.575,.625]:
 arrow(1.9,2.15,2.5,y)
box(4.9,2.35,2.15,1.0,'Raw metrics,\nuncertainty intervals\nand bounded scores')
box(4.9,.9,2.15,1.0,'Governance evidence card\n(no legal verdict)')
for y in [3.475,2.525,1.575,.625]: arrow(4.35,y,4.9,2.85)
arrow(4.35,.625,4.9,1.4)
box(7.65,2.35,2.6,1.0,'Pareto frontier and\nstochastic rank acceptability')
box(7.65,.9,2.6,1.0,'CSV / JSON / HTML reports\nplus reproducible audit bundle')
arrow(7.05,2.85,7.65,2.85);arrow(7.05,1.4,7.65,1.4);arrow(8.95,2.35,8.95,1.9)
ax.text(5.5,4.1,'SynthAudit 2.0 architecture',ha='center',va='center',fontsize=14,fontweight='bold')
fig.tight_layout();fig.savefig(out/'synthaudit_architecture.pdf',bbox_inches='tight');fig.savefig(out/'synthaudit_architecture.png',dpi=300,bbox_inches='tight');plt.close(fig)
