from __future__ import annotations
import argparse, sys
from pathlib import Path
import pandas as pd
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'src'));sys.path.insert(0,str(ROOT/'experiments'))
from paths import RESULTS_DIR
from synthaudit import AuditConfig,audit_many
from generators import generate_dgp,metamorphic_variants
p=argparse.ArgumentParser();p.add_argument('--replicate',type=int,required=True);args=p.parse_args()
rep=args.replicate;seed=100+rep
full=generate_dgp(3600,seed);train=full.iloc[:2400].reset_index(drop=True);test=full.iloc[2400:].reset_index(drop=True)
variants=metamorphic_variants(train,len(train),seed)
cfg=AuditConfig(target='income',protected=('sex','race'),categorical=('education','occupation','sex','race'),numerical=('age','hours','debt'),quasi_identifiers=('age','hours','education','occupation','sex','race'),positive_label='>50K',seed=seed,max_privacy_rows=450,bootstrap_repeats=50,min_group_size=30)
bundle=audit_many(train,test,variants,cfg,n_weight_draws=25000)
out=RESULTS_DIR/'metamorphic'/'replicates';out.mkdir(parents=True,exist_ok=True)
rows=[]
for candidate,row in bundle['scores'].iterrows(): rows.append({'replicate':rep,'candidate':candidate,**row.to_dict()})
pd.DataFrame(rows).to_csv(out/f'scores_{rep:02d}.csv',index=False)
rr=bundle['rank_acceptability'].reset_index();rr['replicate']=rep;rr.to_csv(out/f'ranks_{rep:02d}.csv',index=False)
print(f'completed replicate {rep}')
