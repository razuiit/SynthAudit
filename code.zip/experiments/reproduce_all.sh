#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
RESULTS_DIR="${SYNTHAUDIT_RESULTS_DIR:-$ROOT/results}"
FIGURES_DIR="${SYNTHAUDIT_FIGURES_DIR:-$ROOT/figures}"
cd "$ROOT"

mkdir -p "$RESULTS_DIR" "$FIGURES_DIR"
python -m pip install -e . --no-build-isolation
pytest -q --ignore=tests/test_frozen_results.py

rm -rf "$RESULTS_DIR/metamorphic/replicates"
mkdir -p "$RESULTS_DIR/metamorphic/replicates"
for replicate in $(seq 0 11); do
  python experiments/run_metamorphic_replicate.py --replicate "$replicate"
done
python experiments/aggregate_metamorphic.py

rm -rf "$RESULTS_DIR/adult_case/candidates"
mkdir -p "$RESULTS_DIR/adult_case/candidates"
for candidate in gaussian conditional independent bootstrap; do
  python experiments/run_adult_candidate.py --candidate "$candidate"
done
python experiments/aggregate_adult_case.py
python experiments/make_architecture_figure.py

pytest -q tests/test_frozen_results.py

echo "Reproduction completed."
echo "Tables and reports: $RESULTS_DIR"
echo "Figures: $FIGURES_DIR"
