from __future__ import annotations
import os
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
DATA_DIR = Path(os.environ.get("SYNTHAUDIT_DATA_DIR", ROOT / "data"))
RESULTS_DIR = Path(os.environ.get("SYNTHAUDIT_RESULTS_DIR", ROOT / "results"))
FIGURES_DIR = Path(os.environ.get("SYNTHAUDIT_FIGURES_DIR", ROOT / "figures"))
