from __future__ import annotations
import json,sys
from pathlib import Path
import numpy as np,pandas as pd,matplotlib.pyplot as plt
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT/'src'));sys.path.insert(0,str(ROOT/'experiments'))
from paths import RESULTS_DIR, FIGURES_DIR
from synthaudit.decision import pareto_frontier,rank_acceptability
OUT=RESULTS_DIR/'adult_case';FIG=FIGURES_DIR;FIG.mkdir(parents=True,exist_ok=True)
score_files=sorted((OUT/'candidates').glob('*_scores.csv'))
if len(score_files)!=4: raise SystemExit(f'Expected 4 candidate score files, found {len(score_files)}')
scores=pd.concat([pd.read_csv(f) for f in score_files],ignore_index=True).set_index('candidate')
dims=['privacy','fidelity','downstream_utility','fairness'];scores['pareto_optimal']=pareto_frontier(scores,dims)
ranks=rank_acceptability(scores,dims,n_draws=100000,seed=42)
scores.to_csv(OUT/'dimension_scores.csv');ranks.to_csv(OUT/'rank_acceptability.csv')
details={}
for p in sorted((OUT/'candidates').glob('*_details.json')):
 r=json.loads(p.read_text());details[r['metadata']['generator']]=r
(OUT/'audit_details.json').write_text(json.dumps(details,indent=2),encoding='utf-8')
# HTML report
html=f'''<!doctype html><html><head><meta charset="utf-8"><title>SynthAudit report</title><style>body{{font-family:Arial,sans-serif;max-width:1100px;margin:40px auto;line-height:1.45}}table{{border-collapse:collapse;width:100%;margin-bottom:28px}}th,td{{border:1px solid #ddd;padding:8px;text-align:right}}th:first-child,td:first-child{{text-align:left}}th{{background:#f3f3f3}}.note{{background:#fff7df;padding:14px;border-left:4px solid #d7a600}}</style></head><body><h1>SynthAudit 2.0 report</h1><div class="note">Scores support contextual comparison. Raw metrics and uncertainty intervals remain primary; this report does not determine legal compliance.</div><h2>Dimension scores</h2>{scores.round(4).to_html()}<h2>Rank acceptability</h2>{ranks.round(4).to_html()}</body></html>'''
(OUT/'report.html').write_text(html,encoding='utf-8')
# Figures
fig,ax=plt.subplots(figsize=(9.5,4.8));x=np.arange(len(scores));width=.2
for i,d in enumerate(dims): ax.bar(x+(i-(len(dims)-1)/2)*width,scores[d].values,width,label=d.replace('_',' ').title())
ax.set_xticks(x);ax.set_xticklabels(scores.index,rotation=16,ha='right');ax.set_ylim(0,1.05);ax.set_ylabel('Score (higher is better)');ax.set_title('Adult case study: the preferred generator depends on the audit dimension');ax.legend(ncol=2,frameon=False);fig.tight_layout();fig.savefig(FIG/'adult_dimension_scores.png',dpi=300);fig.savefig(FIG/'adult_dimension_scores.pdf');plt.close(fig)
rank=ranks.sort_values('first_rank_probability',ascending=False);fig,ax=plt.subplots(figsize=(8,4.4));ax.bar(rank.index,rank.first_rank_probability);ax.set_ylim(0,1);ax.set_ylabel('Probability of rank 1');ax.set_title('Adult case study: stochastic rank acceptability over 100,000 random weights');ax.tick_params(axis='x',rotation=18);fig.tight_layout();fig.savefig(FIG/'adult_rank_acceptability.png',dpi=300);fig.savefig(FIG/'adult_rank_acceptability.pdf');plt.close(fig)
print(scores.round(4));print('\n',ranks.sort_values('first_rank_probability',ascending=False).round(4))
