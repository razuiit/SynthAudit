from __future__ import annotations
import argparse,json,sys,re
from pathlib import Path
import numpy as np,pandas as pd
from sklearn.model_selection import train_test_split
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'src'));sys.path.insert(0,str(ROOT/'experiments'))
from paths import DATA_DIR, RESULTS_DIR
from synthaudit import AuditConfig
from synthaudit.audit import audit_dataset
from generators import bootstrap_generator,independent_marginals,conditional_independent,gaussian_copula
COLS=['age','workclass','fnlwgt','education','education-num','marital-status','occupation','relationship','race','sex','capital-gain','capital-loss','hours-per-week','native-country','income']
CAT=['workclass','education','marital-status','occupation','relationship','race','sex','native-country']
NUM=['age','fnlwgt','education-num','capital-gain','capital-loss','hours-per-week']
QIDS=['age','workclass','education','marital-status','occupation','race','sex','native-country']
choices={
 'gaussian':('Empirical Gaussian copula',lambda tr,n:gaussian_copula(tr,CAT+['income'],n,42)),
 'conditional':('Conditional marginals',lambda tr,n:conditional_independent(tr,'income',n,43)),
 'independent':('Independent marginals',lambda tr,n:independent_marginals(tr,n,44)),
 'bootstrap':('Bootstrap memoriser',lambda tr,n:bootstrap_generator(tr,n,45)),
}
p=argparse.ArgumentParser();p.add_argument('--candidate',choices=choices,required=True);args=p.parse_args()
df=pd.read_csv(DATA_DIR/'adult-all.csv',names=COLS,header=None,skipinitialspace=True).replace('?',np.nan)
for c in CAT+['income']:
 df[c]=df[c].astype(str).str.strip();mode=df.loc[df[c]!='nan',c].mode().iat[0];df.loc[df[c]=='nan',c]=mode
for c in NUM: df[c]=pd.to_numeric(df[c],errors='coerce').fillna(pd.to_numeric(df[c],errors='coerce').median())
train,test=train_test_split(df,test_size=.25,random_state=42,stratify=df[['income','sex']].astype(str).agg('_'.join,axis=1));train=train.reset_index(drop=True);test=test.reset_index(drop=True)
key=args.candidate;name,fn=choices[key];syn=fn(train,len(train))
cfg=AuditConfig(target='income',protected=('sex','race'),categorical=tuple(CAT),numerical=tuple(NUM),quasi_identifiers=tuple(QIDS),positive_label='>50K',seed=42,max_privacy_rows=900,bootstrap_repeats=150,min_group_size=40)
res=audit_dataset(train,test,syn,cfg,{'generator':name,'dataset':'UCI Adult'})
out=RESULTS_DIR/'adult_case'/'candidates';out.mkdir(parents=True,exist_ok=True)
pd.DataFrame([{'candidate':name,**res['dimensions']}]).to_csv(out/f'{key}_scores.csv',index=False)
def default(o):
 if hasattr(o,'item'): return o.item()
 raise TypeError(type(o).__name__)
(out/f'{key}_details.json').write_text(json.dumps(res,indent=2,default=default),encoding='utf-8')
syn.to_csv(out/f'{key}_synthetic.csv',index=False)
# Store shared real split once.
if key=='gaussian':
 train.to_csv(RESULTS_DIR/'adult_case'/'real_train.csv',index=False);test.to_csv(RESULTS_DIR/'adult_case'/'real_test.csv',index=False)
print(name,res['dimensions'],flush=True)
