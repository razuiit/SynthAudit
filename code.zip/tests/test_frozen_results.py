from pathlib import Path
import os
import json
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
RESULTS_DIR = Path(os.environ.get("SYNTHAUDIT_RESULTS_DIR", ROOT / "results"))


def test_frozen_metamorphic_selectivity_matches_claims():
    result = pd.read_csv(RESULTS_DIR / "metamorphic" / "metamorphic_selectivity.csv")
    assert (result["intended_dimension"] == result["largest_loss_dimension"]).all()
    assert set(result["candidate"]) == {
        "Memorising", "Independent marginals", "Bias amplified", "Range corrupted", "Mode collapsed"
    }


def test_frozen_adult_memoriser_is_privacy_failure():
    scores = pd.read_csv(RESULTS_DIR / "adult_case" / "dimension_scores.csv").set_index("candidate")
    assert scores.loc["Bootstrap memoriser", "privacy"] == 0.0
    assert scores.loc["Bootstrap memoriser", "fidelity"] > 0.99
    details = json.loads((RESULTS_DIR / "adult_case" / "candidates" / "bootstrap_details.json").read_text())
    assert details["privacy"]["exact_match_rate"] == 1.0


def test_frozen_adult_rank_probabilities_sum_to_one():
    ranks = pd.read_csv(RESULTS_DIR / "adult_case" / "rank_acceptability.csv")
    assert abs(ranks["first_rank_probability"].sum() - 1.0) < 1e-12
