# Data

## UCI Adult

`adult-all.csv` is used only for the reproducible case study. The source is the UCI Machine Learning Repository, Adult dataset, DOI `10.24432/C5XW20`, distributed by UCI under its stated CC BY 4.0 licence. The paper discusses limitations of Adult as a contemporary social benchmark; it is used here because it provides a familiar mixed-type binary task with protected attributes.

## Excluded exploratory data

Earlier exploratory datasets that are not used in the SoftwareX manuscript are intentionally excluded from this release. This avoids unnecessary redistribution and makes the exact evidence base unambiguous.

## Release recommendation

Before archival deposition, retain only data that are necessary and whose redistribution terms have been checked. A conservative public release can include a download/preparation script instead of redistributing source datasets.
