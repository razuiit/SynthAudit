# SynthAudit 2.0

SynthAudit is an open-source Python package for **uncertainty-aware, multi-objective auditing of synthetic tabular data**. It reports raw diagnostics and contextual comparison scores across:

- privacy leakage (nearest-synthetic membership inference and exact matches),
- statistical fidelity (univariate distributions and multivariate associations),
- downstream utility (train-synthetic/test-real performance against a real-trained reference),
- group-fairness preservation (drift from a real-trained reference), and
- decision robustness (Pareto status and stochastic rank acceptability under uncertain stakeholder weights).

SynthAudit deliberately **does not issue a legal-compliance verdict**. It exports a governance evidence card that documents the evidence, assumptions, and limitations requiring expert review.

## Installation

```bash
python -m pip install -e . --no-build-isolation
```

## Command-line example

```bash
synthaudit audit \
  --real-train results/adult_case/real_train.csv \
  --real-test results/adult_case/real_test.csv \
  --synthetic "Copula=results/adult_case/candidates/gaussian_synthetic.csv" \
  --synthetic "Bootstrap=results/adult_case/candidates/bootstrap_synthetic.csv" \
  --target income \
  --protected sex,race \
  --categorical workclass,education,marital-status,occupation,relationship,race,sex,native-country \
  --numerical age,fnlwgt,education-num,capital-gain,capital-loss,hours-per-week \
  --quasi-identifiers age,workclass,education,marital-status,occupation,race,sex,native-country \
  --positive-label ">50K" \
  --output audit_output
```

The output directory contains `dimension_scores.csv`, `rank_acceptability.csv`, `audit_details.json`, and a standalone `report.html`.

## Reproduce the paper

```bash
python -m pip install -r requirements-lock.txt
bash experiments/reproduce_all.sh
```

The orchestration script installs the package, runs the tests, executes 12 metamorphic replicates and four Adult candidates in isolated processes, aggregates results, and regenerates the figures. Frozen outputs are included for comparison. The exact tested dependency versions are recorded in `requirements-lock.txt` and `environment-tested.txt`.

## Repository structure

- `src/synthaudit/`: reusable package and CLI
- `experiments/`: reproducible study scripts
- `tests/`: unit and metamorphic tests
- `results/`: generated tables and reports
- `figures/`: publication figures
- `paper/`: SoftwareX manuscript and submission documents
- `supplementary/`: extended methods and metric definitions

## Important interpretation rules

1. Raw metrics and confidence intervals are primary; composite dimension scores are decision aids.
2. Privacy tests are empirical attacks, not proofs of anonymity or differential privacy.
3. Fairness is conditional on selected protected attributes, outcomes, models, and holdout data.
4. Rank acceptability describes robustness to uncertain priorities; it does not create a universal best generator.
5. The governance evidence card does not determine compliance with GDPR, HIPAA, the EU AI Act, or any other law.

## License

MIT.


## Release and citation

The release includes `CITATION.cff` and `.zenodo.json`. Before journal submission, create a public repository, archive the exact `v2.0.0` release, and replace every repository/DOI placeholder. See `submission/author_checks.md`.
