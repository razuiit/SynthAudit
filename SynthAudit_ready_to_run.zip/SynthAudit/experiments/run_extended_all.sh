#!/usr/bin/env bash
# Extended validation for the SoftwareX revision: 3 datasets x 6 generators.  RESUMABLE:
# a candidate whose output already exists is skipped, so after a Colab disconnect just run it again.
# Usage:  bash experiments/run_extended_all.sh [EPOCHS] [CENSUS_MAX_ROWS] ["datasets"]
#   quick test (writes to results/smoke, never mixed with real results):
#       OUT_ROOT=results/smoke bash experiments/run_extended_all.sh 5 5000
#   full run, one dataset:  bash experiments/run_extended_all.sh 300 40000 "credit"
set -euo pipefail
EPOCHS="${1:-300}"; CENSUS_ROWS="${2:-40000}"; DATASETS="${3:-adult credit census}"
OUT="${OUT_ROOT:-results/extended}"
cd "$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
python -c "import ctgan, xlrd" 2>/dev/null || python -m pip install -q ctgan xlrd
for ds in $DATASETS; do
  rows=""; [ "$ds" = "census" ] && rows="--max-rows $CENSUS_ROWS"
  for c in gaussian conditional independent bootstrap ctgan tvae; do
    if [ -f "$OUT/$ds/candidates/${c}_synthetic.csv" ]; then echo "skip $ds/$c (already done)"; continue; fi
    python experiments/run_extended_candidate.py --dataset "$ds" --candidate "$c" --epochs "$EPOCHS" --out-root "$OUT" $rows
  done
  python experiments/aggregate_extended.py --dataset "$ds" --out-root "$OUT"
done
echo "Done. Results are in $OUT/"
