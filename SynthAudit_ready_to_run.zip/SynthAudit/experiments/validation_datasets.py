"""Dataset definitions for the extended validation (revision of SOFTX-D-26-00992).

Three datasets, one common interface:  load(name, data_dir, max_rows) -> (df, spec)

Files expected in ``data/`` (downloaded manually from the UCI repository):
  adult      : adult-all.csv                         (already in the release)
  credit     : credit_default.csv  (or .xls/.xlsx)   UCI id 350
  census     : census-income.data(.gz) and census-income.test(.gz)   UCI id 117
"""
from __future__ import annotations
from dataclasses import dataclass
from pathlib import Path
import numpy as np
import pandas as pd


@dataclass
class Spec:
    name: str
    target: str
    positive_label: str
    protected: tuple
    categorical: list      # excludes the target
    numerical: list
    quasi_identifiers: tuple
    stratify_cols: tuple   # used for the train/holdout split


def _clean(df: pd.DataFrame, cat: list, num: list, target: str) -> pd.DataFrame:
    """Same preprocessing as the Adult case study: '?' -> missing, then mode / median imputation."""
    df = df.replace("?", np.nan)
    n_missing = int(df.isna().sum().sum())
    for c in cat + [target]:
        s = df[c].astype(str).str.strip()
        s = s.where(s != "nan", np.nan)
        df[c] = s.fillna(s.mode().iat[0])
    for c in num:
        x = pd.to_numeric(df[c], errors="coerce")
        df[c] = x.fillna(x.median())
    df.attrs["n_missing_before_imputation"] = n_missing
    return df


# ------------------------------------------------------------------ Adult
ADULT_COLS = ['age', 'workclass', 'fnlwgt', 'education', 'education-num', 'marital-status', 'occupation',
              'relationship', 'race', 'sex', 'capital-gain', 'capital-loss', 'hours-per-week',
              'native-country', 'income']


def _adult(data_dir: Path):
    cat = ['workclass', 'education', 'marital-status', 'occupation', 'relationship', 'race', 'sex', 'native-country']
    num = ['age', 'fnlwgt', 'education-num', 'capital-gain', 'capital-loss', 'hours-per-week']
    df = pd.read_csv(data_dir / 'adult-all.csv', names=ADULT_COLS, header=None, skipinitialspace=True)
    spec = Spec('adult', 'income', '>50K', ('sex', 'race'), cat, num,
                ('age', 'workclass', 'education', 'marital-status', 'occupation', 'race', 'sex', 'native-country'),
                ('income', 'sex'))
    return _clean(df, cat, num, 'income'), spec


# ------------------------------------------------------------------ Credit default
def _credit(data_dir: Path):
    csv = data_dir / 'credit_default.csv'
    if csv.exists():
        df = pd.read_csv(csv)
    else:
        xl = next(iter(list(data_dir.glob('default*credit*.xls*')) + list(data_dir.glob('credit_default.xls*'))), None)
        if xl is None:
            raise FileNotFoundError("Put credit_default.csv (or the UCI .xls file) in data/")
        df = pd.read_excel(xl, header=1)
    if 'LIMIT_BAL' not in df.columns:               # UCI sheet has a label row above the header
        df.columns = df.iloc[0]; df = df.iloc[1:].reset_index(drop=True)
    df = df.rename(columns={'PAY_0': 'PAY_1', 'default payment next month': 'default',
                            'default.payment.next.month': 'default'})
    df = df.drop(columns=[c for c in ('ID',) if c in df.columns])
    for c in df.columns:
        df[c] = pd.to_numeric(df[c], errors='coerce')
    df['default'] = df['default'].map({1: 'default', 0: 'no_default'})
    cat = ['SEX', 'EDUCATION', 'MARRIAGE']
    for c in cat:
        df[c] = df[c].astype('Int64').astype(str)
    num = [c for c in df.columns if c not in cat + ['default']]
    spec = Spec('credit', 'default', 'default', ('SEX', 'MARRIAGE'), cat, num,
                ('AGE', 'SEX', 'EDUCATION', 'MARRIAGE', 'LIMIT_BAL'), ('default', 'SEX'))
    return _clean(df[num + cat + ['default']], cat, num, 'default'), spec


# ------------------------------------------------------------------ Census-Income (KDD)
CENSUS_COLS = [
    'age', 'class_of_worker', 'industry_recode', 'occupation_recode', 'education', 'wage_per_hour',
    'enrolled_edu', 'marital_status', 'major_industry', 'major_occupation', 'race', 'hispanic_origin',
    'sex', 'union_member', 'unemployment_reason', 'employment_status', 'capital_gains', 'capital_losses',
    'dividends', 'tax_filer', 'prev_region', 'prev_state', 'household_family_stat', 'household_summary',
    'instance_weight', 'mig_msa', 'mig_reg', 'mig_within_reg', 'same_house_1yr', 'mig_sunbelt',
    'num_employers', 'family_under18', 'father_birth_country', 'mother_birth_country', 'birth_country',
    'citizenship', 'self_employed', 'veterans_questionnaire', 'veterans_benefits', 'weeks_worked',
    'year', 'income']


def _census(data_dir: Path):
    parts = []
    for stem in ('census-income.data', 'census-income.test'):
        f = next(iter(sorted(data_dir.glob(stem + '*'))), None)
        if f is None:
            raise FileNotFoundError(f"Put {stem}(.gz) in data/")
        parts.append(pd.read_csv(f, header=None, skipinitialspace=True, low_memory=False))
    df = pd.concat(parts, ignore_index=True)
    if df.shape[1] != len(CENSUS_COLS):
        raise ValueError(f"Expected {len(CENSUS_COLS)} columns, found {df.shape[1]}")
    df.columns = CENSUS_COLS
    df = df.drop(columns=['instance_weight'])         # sampling weight, not a feature -> 40 features + label
    num = ['age', 'wage_per_hour', 'capital_gains', 'capital_losses', 'dividends', 'num_employers', 'weeks_worked']
    first = ['sex', 'race', 'education', 'marital_status', 'class_of_worker', 'major_occupation', 'birth_country']
    cat = first + [c for c in df.columns if c not in num + first + ['income']]   # protected + QIDs first
    spec = Spec('census', 'income', '50000+.', ('sex', 'race'), cat, num,
                ('age', 'sex', 'race', 'education', 'marital_status', 'class_of_worker', 'major_occupation',
                 'birth_country'), ('income', 'sex'))
    return _clean(df[num + cat + ['income']], cat, num, 'income'), spec


LOADERS = {'adult': _adult, 'credit': _credit, 'census': _census}


def load(name: str, data_dir: Path, max_rows: int | None = None, seed: int = 42):
    df, spec = LOADERS[name](Path(data_dir))
    if max_rows and len(df) > max_rows:
        df = df.sample(n=max_rows, random_state=seed).reset_index(drop=True)
    return df, spec
