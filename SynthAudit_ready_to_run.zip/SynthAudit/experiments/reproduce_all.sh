#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT"

python -m pip install -e . --no-build-isolation
pytest -q

rm -rf results/metamorphic/replicates
mkdir -p results/metamorphic/replicates
for replicate in $(seq 0 11); do
  python experiments/run_metamorphic_replicate.py --replicate "$replicate"
done
python experiments/aggregate_metamorphic.py

rm -rf results/adult_case/candidates
mkdir -p results/adult_case/candidates
for candidate in gaussian conditional independent bootstrap; do
  python experiments/run_adult_candidate.py --candidate "$candidate"
done
python experiments/aggregate_adult_case.py
python experiments/make_architecture_figure.py

echo "Reproduction completed. See results/ and figures/."
