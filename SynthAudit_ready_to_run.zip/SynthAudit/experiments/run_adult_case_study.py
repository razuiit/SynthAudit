from __future__ import annotations
import json
import sys
from pathlib import Path
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))
sys.path.insert(0, str(ROOT / "experiments"))
from synthaudit import AuditConfig, audit_many
from synthaudit.report import save_audit_bundle
from generators import bootstrap_generator, independent_marginals, conditional_independent, gaussian_copula

COLS = ["age", "workclass", "fnlwgt", "education", "education-num", "marital-status", "occupation",
        "relationship", "race", "sex", "capital-gain", "capital-loss", "hours-per-week", "native-country", "income"]
CATEGORICAL = ["workclass", "education", "marital-status", "occupation", "relationship", "race", "sex", "native-country"]
NUMERICAL = ["age", "fnlwgt", "education-num", "capital-gain", "capital-loss", "hours-per-week"]
QIDS = ["age", "workclass", "education", "marital-status", "occupation", "race", "sex", "native-country"]

df = pd.read_csv(ROOT / "data" / "adult-all.csv", names=COLS, header=None, skipinitialspace=True)
df = df.replace("?", np.nan)
for c in CATEGORICAL + ["income"]:
    df[c] = df[c].astype(str).str.strip()
    if df[c].isna().any() or (df[c] == "nan").any():
        mode = df.loc[df[c] != "nan", c].mode().iat[0]
        df.loc[df[c] == "nan", c] = mode
for c in NUMERICAL:
    df[c] = pd.to_numeric(df[c], errors="coerce").fillna(pd.to_numeric(df[c], errors="coerce").median())
train, test = train_test_split(df, test_size=0.25, random_state=42, stratify=df[["income", "sex"]].astype(str).agg("_".join, axis=1))
train, test = train.reset_index(drop=True), test.reset_index(drop=True)
n = len(train)
cat_with_target = CATEGORICAL + ["income"]
variants = {
    "Empirical Gaussian copula": gaussian_copula(train, cat_with_target, n, 42),
    "Conditional marginals": conditional_independent(train, "income", n, 43),
    "Independent marginals": independent_marginals(train, n, 44),
    "Bootstrap memoriser": bootstrap_generator(train, n, 45),
}
cfg = AuditConfig(target="income", protected=("sex", "race"), categorical=tuple(CATEGORICAL), numerical=tuple(NUMERICAL),
                  quasi_identifiers=tuple(QIDS), positive_label=">50K", seed=42, max_privacy_rows=900,
                  bootstrap_repeats=150, min_group_size=40)
bundle = audit_many(train, test, variants, cfg, n_weight_draws=100000)
out = ROOT / "results" / "adult_case"
save_audit_bundle(bundle, out)
train.to_csv(out / "real_train.csv", index=False); test.to_csv(out / "real_test.csv", index=False)
for name, frame in variants.items():
    frame.to_csv(out / (name.lower().replace(" ", "_") + ".csv"), index=False)

scores = bundle["scores"]
dims = bundle["dimensions_used"]
fig, ax = plt.subplots(figsize=(9.5, 4.8))
x = np.arange(len(scores.index)); width = 0.2
for i, d in enumerate(dims):
    ax.bar(x + (i - (len(dims)-1)/2) * width, scores[d].values, width, label=d.replace("_", " ").title())
ax.set_xticks(x); ax.set_xticklabels(scores.index, rotation=16, ha="right")
ax.set_ylim(0, 1.05); ax.set_ylabel("Score (higher is better)")
ax.set_title("Adult case study: the preferred generator depends on the audit dimension")
ax.legend(ncol=2, frameon=False); fig.tight_layout()
fig.savefig(ROOT / "figures" / "adult_dimension_scores.png", dpi=300); fig.savefig(ROOT / "figures" / "adult_dimension_scores.pdf"); plt.close(fig)

rank = bundle["rank_acceptability"].sort_values("first_rank_probability", ascending=False)
fig, ax = plt.subplots(figsize=(8, 4.4)); ax.bar(rank.index, rank.first_rank_probability)
ax.set_ylim(0, 1); ax.set_ylabel("Probability of rank 1")
ax.set_title("Adult case study: stochastic rank acceptability over 100,000 random weights")
ax.tick_params(axis="x", rotation=18); fig.tight_layout()
fig.savefig(ROOT / "figures" / "adult_rank_acceptability.png", dpi=300); fig.savefig(ROOT / "figures" / "adult_rank_acceptability.pdf"); plt.close(fig)
print(scores.round(4)); print(rank.round(4))
