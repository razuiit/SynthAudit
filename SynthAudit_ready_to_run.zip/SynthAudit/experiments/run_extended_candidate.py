"""Run ONE candidate generator on ONE dataset and audit it with SynthAudit.

Examples
  python experiments/run_extended_candidate.py --dataset credit --candidate ctgan --epochs 300
  python experiments/run_extended_candidate.py --dataset census --candidate tvae --max-rows 40000
"""
from __future__ import annotations
import argparse, json, sys, time
from pathlib import Path
import pandas as pd
from sklearn.model_selection import train_test_split

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'src')); sys.path.insert(0, str(ROOT / 'experiments'))
from synthaudit import AuditConfig
from synthaudit.audit import audit_dataset
import generators as G
from validation_datasets import load

CANDIDATES = ['gaussian', 'conditional', 'independent', 'bootstrap', 'ctgan', 'tvae']


def build_generators(spec, epochs, batch_size):
    disc = spec.categorical + [spec.target]
    return {
        'gaussian': ('Empirical Gaussian copula', lambda tr, n: G.gaussian_copula(tr, disc, n, 42)),
        'conditional': ('Conditional marginals', lambda tr, n: G.conditional_independent(tr, spec.target, n, 43)),
        'independent': ('Independent marginals', lambda tr, n: G.independent_marginals(tr, n, 44)),
        'bootstrap': ('Bootstrap memoriser', lambda tr, n: G.bootstrap_generator(tr, n, 45)),
        'ctgan': ('CTGAN', lambda tr, n: G.ctgan_generator(tr, disc, n, 46, epochs, batch_size)),
        'tvae': ('TVAE', lambda tr, n: G.tvae_generator(tr, disc, n, 47, epochs, batch_size)),
    }


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--dataset', choices=['adult', 'credit', 'census'], required=True)
    ap.add_argument('--candidate', choices=CANDIDATES, required=True)
    ap.add_argument('--max-rows', type=int, default=None, help='subsample the real table before splitting')
    ap.add_argument('--epochs', type=int, default=300)
    ap.add_argument('--batch-size', type=int, default=500)
    ap.add_argument('--data-dir', default=str(ROOT / 'data'))
    ap.add_argument('--out-root', default=str(ROOT / 'results' / 'extended'))
    a = ap.parse_args()

    df, spec = load(a.dataset, a.data_dir, a.max_rows)
    strat = df[list(spec.stratify_cols)].astype(str).agg('_'.join, axis=1)
    train, test = train_test_split(df, test_size=.25, random_state=42, stratify=strat)
    train, test = train.reset_index(drop=True), test.reset_index(drop=True)

    name, fn = build_generators(spec, a.epochs, a.batch_size)[a.candidate]
    t0 = time.time(); syn = fn(train, len(train)); gen_s = time.time() - t0

    cfg = AuditConfig(target=spec.target, protected=spec.protected, categorical=tuple(spec.categorical),
                      numerical=tuple(spec.numerical), quasi_identifiers=spec.quasi_identifiers,
                      positive_label=spec.positive_label, seed=42, max_privacy_rows=900,
                      bootstrap_repeats=150, min_group_size=40)
    meta = {'generator': name, 'dataset': spec.name, 'n_train': len(train), 'n_holdout': len(test),
            'n_columns': df.shape[1], 'n_missing_before_imputation': df.attrs.get('n_missing_before_imputation'),
            'generator_seconds': round(gen_s, 1), 'epochs': a.epochs if a.candidate in ('ctgan', 'tvae') else None}
    t0 = time.time(); res = audit_dataset(train, test, syn, cfg, meta); meta['audit_seconds'] = round(time.time() - t0, 1)
    res['metadata'].update({k: meta[k] for k in ('audit_seconds',)})

    out = Path(a.out_root) / spec.name / 'candidates'; out.mkdir(parents=True, exist_ok=True)
    pd.DataFrame([{'candidate': name, **res['dimensions']}]).to_csv(out / f'{a.candidate}_scores.csv', index=False)
    default = lambda o: o.item() if hasattr(o, 'item') else (_ for _ in ()).throw(TypeError(type(o).__name__))
    (out / f'{a.candidate}_details.json').write_text(json.dumps(res, indent=2, default=default), encoding='utf-8')
    syn.to_csv(out / f'{a.candidate}_synthetic.csv', index=False)
    train.to_csv(out.parent / 'real_train.csv', index=False); test.to_csv(out.parent / 'real_test.csv', index=False)
    print(f"[{spec.name}] {name}: {res['dimensions']}  (generate {gen_s:.0f}s, audit {meta['audit_seconds']}s)", flush=True)


if __name__ == '__main__':
    main()
