"""Combine the six candidate audits of one dataset: Pareto status, rank acceptability, LaTeX rows."""
from __future__ import annotations
import argparse, json, sys
from pathlib import Path
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]; sys.path.insert(0, str(ROOT / 'src'))
from synthaudit.decision import pareto_frontier, rank_acceptability

ORDER = ['Empirical Gaussian copula', 'Conditional marginals', 'Independent marginals',
         'Bootstrap memoriser', 'CTGAN', 'TVAE']
DIMS = ['privacy', 'fidelity', 'downstream_utility', 'fairness']

ap = argparse.ArgumentParser(); ap.add_argument('--dataset', required=True)
ap.add_argument('--out-root', default=str(ROOT / 'results' / 'extended')); a = ap.parse_args()
out = Path(a.out_root) / a.dataset
files = sorted((out / 'candidates').glob('*_scores.csv'))
if len(files) != 6:
    raise SystemExit(f'Expected 6 candidate score files for {a.dataset}, found {len(files)}')
scores = pd.concat([pd.read_csv(f) for f in files], ignore_index=True).set_index('candidate').loc[ORDER]
scores['pareto_optimal'] = pareto_frontier(scores, DIMS)
ranks = rank_acceptability(scores, DIMS, n_draws=100000, seed=42)
scores.to_csv(out / 'dimension_scores.csv'); ranks.to_csv(out / 'rank_acceptability.csv')

rows = []
for cand in ORDER:
    s, r = scores.loc[cand], ranks.loc[cand, 'first_rank_probability']
    rows.append(f"{cand} & {s.privacy:.3f} & {s.fidelity:.3f} & {s.downstream_utility:.3f} & {s.fairness:.3f} "
                f"& {'Yes' if s.pareto_optimal else 'No'} & {r:.3f} \\\\")
(out / 'table_rows.tex').write_text('\n'.join(rows) + '\n', encoding='utf-8')

runtime = {}
for p in sorted((out / 'candidates').glob('*_details.json')):
    d = json.loads(p.read_text()); m = d['metadata']
    runtime[m['generator']] = {k: m.get(k) for k in ('n_train', 'n_columns', 'generator_seconds', 'audit_seconds',
                                                      'n_missing_before_imputation')}
(out / 'runtime.json').write_text(json.dumps(runtime, indent=2), encoding='utf-8')
print(scores.round(3)); print(); print(ranks.round(3)); print(); print((out / 'table_rows.tex').read_text())
