from __future__ import annotations
from pathlib import Path
import numpy as np, pandas as pd, matplotlib.pyplot as plt
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'results'/'metamorphic';FIG=ROOT/'figures';FIG.mkdir(exist_ok=True)
score_files=sorted((OUT/'replicates').glob('scores_*.csv'));rank_files=sorted((OUT/'replicates').glob('ranks_*.csv'))
if len(score_files)<8: raise SystemExit(f'Need >=8 replicates, found {len(score_files)}')
raw=pd.concat([pd.read_csv(f) for f in score_files],ignore_index=True);ranks=pd.concat([pd.read_csv(f) for f in rank_files],ignore_index=True)
raw.to_csv(OUT/'metamorphic_raw.csv',index=False);ranks.to_csv(OUT/'metamorphic_rank_raw.csv',index=False)
dims=['privacy','fidelity','downstream_utility','fairness'];summary=raw.groupby('candidate')[dims].agg(['mean','std','count']);summary.to_csv(OUT/'metamorphic_summary.csv')
order=['Ideal DGP','Memorising','Independent marginals','Bias amplified','Range corrupted','Mode collapsed']
means=raw.groupby('candidate')[dims].mean().loc[order];ses=raw.groupby('candidate')[dims].sem().loc[order]
x=np.arange(len(order));width=.19
fig,ax=plt.subplots(figsize=(11,5.6))
for i,d in enumerate(dims): ax.bar(x+(i-1.5)*width,means[d],width,yerr=1.96*ses[d],capsize=3,label=d.replace('_',' ').title())
ax.set_xticks(x);ax.set_xticklabels(order,rotation=18,ha='right');ax.set_ylim(0,1.05);ax.set_ylabel('Score (higher is better)');ax.set_title('Metamorphic validation: injected failures are exposed by the intended audit dimensions');ax.legend(ncol=2,frameon=False);fig.tight_layout();fig.savefig(FIG/'metamorphic_module_scores.png',dpi=300);fig.savefig(FIG/'metamorphic_module_scores.pdf');plt.close(fig)
loss=means.loc[order[1:]].copy()
for d in dims: loss[d]=means.loc['Ideal DGP',d]-loss[d]
fig,ax=plt.subplots(figsize=(8.5,4.7));im=ax.imshow(loss[dims].to_numpy(),aspect='auto',vmin=-.15,vmax=max(.35,float(loss.max().max())));ax.set_yticks(np.arange(len(loss)));ax.set_yticklabels(loss.index);ax.set_xticks(np.arange(len(dims)));ax.set_xticklabels([d.replace('_',' ').title() for d in dims],rotation=20,ha='right')
for i in range(loss.shape[0]):
  for j in range(loss.shape[1]): ax.text(j,i,f'{loss.iat[i,j]:.2f}',ha='center',va='center')
ax.set_title('Score loss relative to an independent sample from the same data-generating process');fig.colorbar(im,ax=ax,label='Loss relative to ideal');fig.tight_layout();fig.savefig(FIG/'metamorphic_diagnostic_heatmap.png',dpi=300);fig.savefig(FIG/'metamorphic_diagnostic_heatmap.pdf');plt.close(fig)
rank_summary=ranks.groupby('candidate')['first_rank_probability'].mean().sort_values(ascending=False)
fig,ax=plt.subplots(figsize=(8,4.5));ax.bar(rank_summary.index,rank_summary.values);ax.set_ylim(0,1);ax.set_ylabel('Probability of rank 1');ax.set_title('Stochastic rank acceptability under 25,000 random stakeholder weight vectors per replicate');ax.tick_params(axis='x',rotation=20);fig.tight_layout();fig.savefig(FIG/'metamorphic_rank_acceptability.png',dpi=300);fig.savefig(FIG/'metamorphic_rank_acceptability.pdf');plt.close(fig)
# Diagnostic selectivity statistics: intended failure dimension vs other dimensions
intent={'Memorising':'privacy','Independent marginals':'downstream_utility','Bias amplified':'fairness','Range corrupted':'fidelity','Mode collapsed':'fidelity'}
records=[]
for cand,dim in intent.items():
    sub=raw[raw.candidate==cand].set_index('replicate');ideal=raw[raw.candidate=='Ideal DGP'].set_index('replicate');losses=ideal[dims]-sub[dims]
    records.append({'candidate':cand,'intended_dimension':dim,'intended_mean_loss':losses[dim].mean(),'largest_loss_dimension':losses.mean().idxmax(),'largest_mean_loss':losses.mean().max()})
pd.DataFrame(records).to_csv(OUT/'metamorphic_selectivity.csv',index=False)
print(summary.round(4));print('\nRank 1 probability\n',rank_summary.round(4))
