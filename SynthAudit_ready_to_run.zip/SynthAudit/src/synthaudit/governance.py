from __future__ import annotations
from datetime import datetime, timezone


def evidence_card(config, privacy, utility, fairness, metadata=None):
    metadata = metadata or {}
    return {
        "generated_at_utc": datetime.now(timezone.utc).isoformat(),
        "intended_use": metadata.get("intended_use", "Not supplied"),
        "generator": metadata.get("generator", "Not supplied"),
        "data_provenance": metadata.get("data_provenance", "Not supplied"),
        "target": config.target,
        "protected_attributes": list(config.protected),
        "quasi_identifiers": list(config.quasi_identifiers or []),
        "privacy_evidence": {
            "membership_attack_auc": privacy["membership_inference"]["attack_auc"],
            "membership_attack_auc_ci95": privacy["membership_inference"]["attack_auc_ci95"],
            "exact_match_rate": privacy["exact_match_rate"],
        },
        "utility_evidence": {
            "univariate_fidelity": utility["univariate"]["score"],
            "dependency_fidelity": utility["dependency"]["score"],
            "downstream_retention": utility["downstream"]["score"],
        },
        "fairness_evidence": {
            "preservation_score": fairness.get("score"),
            "attributes_evaluated": list(config.protected),
        },
        "limitations": [
            "Empirical privacy tests do not prove anonymity or differential privacy.",
            "Fairness metrics are conditional on the selected target, protected groups, classifier family, and test set.",
            "No legal-compliance determination is produced; domain, ethics, and legal review remain necessary.",
            "Scores support comparison within a declared context and should not be treated as universal pass/fail thresholds.",
        ],
    }
