from __future__ import annotations
import json
from pathlib import Path
import pandas as pd


def _json_default(obj):
    if hasattr(obj, "item"):
        return obj.item()
    raise TypeError(type(obj).__name__)


def save_audit_bundle(bundle, output_dir):
    out = Path(output_dir)
    out.mkdir(parents=True, exist_ok=True)
    bundle["scores"].to_csv(out / "dimension_scores.csv")
    bundle["rank_acceptability"].to_csv(out / "rank_acceptability.csv")
    with (out / "audit_details.json").open("w", encoding="utf-8") as f:
        json.dump(bundle["details"], f, indent=2, default=_json_default)
    score_html = bundle["scores"].round(4).to_html(classes="table", border=0)
    rank_html = bundle["rank_acceptability"].round(4).to_html(classes="table", border=0)
    html = f"""<!doctype html><html><head><meta charset='utf-8'><title>SynthAudit report</title>
<style>body{{font-family:Arial,sans-serif;max-width:1100px;margin:40px auto;line-height:1.45}}.table{{border-collapse:collapse;width:100%;margin-bottom:28px}}th,td{{border:1px solid #ddd;padding:8px;text-align:right}}th:first-child,td:first-child{{text-align:left}}th{{background:#f3f3f3}}.note{{background:#fff7df;padding:14px;border-left:4px solid #d7a600}}</style></head><body>
<h1>SynthAudit 2.0 report</h1><div class='note'>Scores support contextual comparison. Raw metrics and uncertainty intervals remain primary; this report does not determine legal compliance.</div>
<h2>Dimension scores and Pareto status</h2>{score_html}<h2>Stochastic rank acceptability</h2>{rank_html}
<p>Detailed per-metric outputs and governance evidence cards are in <code>audit_details.json</code>.</p></body></html>"""
    (out / "report.html").write_text(html, encoding="utf-8")
