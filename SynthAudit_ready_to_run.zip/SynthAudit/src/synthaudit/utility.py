from __future__ import annotations
import math
import numpy as np
import pandas as pd
from scipy.stats import wasserstein_distance
from sklearn.compose import ColumnTransformer
from sklearn.ensemble import RandomForestClassifier
from sklearn.linear_model import SGDClassifier
from sklearn.metrics import balanced_accuracy_score, f1_score, roc_auc_score
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder, RobustScaler
from .preprocessing import robust_numeric_scale


def _tvd_similarity(a: pd.Series, b: pd.Series) -> float:
    pa = a.astype(str).value_counts(normalize=True)
    pb = b.astype(str).value_counts(normalize=True)
    cats = pa.index.union(pb.index)
    tvd = 0.5 * float(np.abs(pa.reindex(cats, fill_value=0) - pb.reindex(cats, fill_value=0)).sum())
    return float(np.clip(1.0 - tvd, 0, 1))


def univariate_fidelity(real: pd.DataFrame, synth: pd.DataFrame, categorical: list[str], numerical: list[str]):
    per_column = {}
    for c in numerical:
        r = pd.to_numeric(real[c], errors="coerce").dropna()
        s = pd.to_numeric(synth[c], errors="coerce").dropna()
        if len(r) == 0 or len(s) == 0:
            score = np.nan
        else:
            w = wasserstein_distance(r, s)
            scale = robust_numeric_scale(r)
            score = math.exp(-float(w) / max(scale, 1e-12))
        per_column[c] = float(score) if np.isfinite(score) else np.nan
    for c in categorical:
        per_column[c] = _tvd_similarity(real[c], synth[c])
    vals = [v for v in per_column.values() if np.isfinite(v)]
    return {"score": float(np.mean(vals)) if vals else np.nan, "per_column": per_column}


def _cramers_v(x: pd.Series, y: pd.Series) -> float:
    table = pd.crosstab(x.astype(str), y.astype(str)).to_numpy(float)
    n = table.sum()
    if n <= 1 or table.shape[0] < 2 or table.shape[1] < 2:
        return 0.0
    expected = np.outer(table.sum(axis=1), table.sum(axis=0)) / n
    mask = expected > 0
    chi2 = ((table - expected) ** 2 / np.where(mask, expected, 1)).sum()
    phi2 = chi2 / n
    r, k = table.shape
    phi2corr = max(0.0, phi2 - ((k - 1) * (r - 1)) / max(n - 1, 1))
    rcorr = r - ((r - 1) ** 2) / max(n - 1, 1)
    kcorr = k - ((k - 1) ** 2) / max(n - 1, 1)
    denom = min(kcorr - 1, rcorr - 1)
    return float(np.sqrt(phi2corr / denom)) if denom > 0 else 0.0


def _correlation_ratio(categories: pd.Series, values: pd.Series) -> float:
    cat = categories.astype(str)
    val = pd.to_numeric(values, errors="coerce")
    ok = val.notna() & cat.notna()
    cat, val = cat[ok], val[ok]
    if len(val) < 2:
        return 0.0
    grand = val.mean()
    numerator = 0.0
    for _, g in val.groupby(cat):
        numerator += len(g) * (g.mean() - grand) ** 2
    denominator = float(((val - grand) ** 2).sum())
    return float(np.sqrt(numerator / denominator)) if denominator > 0 else 0.0


def association_matrix(df: pd.DataFrame, categorical: list[str], numerical: list[str], max_columns: int = 24):
    cols = (numerical + categorical)[:max_columns]
    mat = pd.DataFrame(np.eye(len(cols)), index=cols, columns=cols, dtype=float)
    for i, a in enumerate(cols):
        for j in range(i + 1, len(cols)):
            b = cols[j]
            if a in numerical and b in numerical:
                v = pd.to_numeric(df[a], errors="coerce").corr(pd.to_numeric(df[b], errors="coerce"), method="spearman")
                v = 0.0 if not np.isfinite(v) else float(v)
            elif a in categorical and b in categorical:
                v = _cramers_v(df[a], df[b])
            elif a in categorical:
                v = _correlation_ratio(df[a], df[b])
            else:
                v = _correlation_ratio(df[b], df[a])
            mat.iat[i, j] = mat.iat[j, i] = v
    return mat


def dependency_fidelity(real: pd.DataFrame, synth: pd.DataFrame, categorical: list[str], numerical: list[str]):
    r = association_matrix(real, categorical, numerical)
    s = association_matrix(synth, categorical, numerical)
    diff = np.abs(r.to_numpy() - s.to_numpy())
    tri = diff[np.triu_indices_from(diff, k=1)]
    score = float(np.clip(1.0 - np.mean(tri), 0, 1)) if len(tri) else 1.0
    # Directional sign errors are meaningful only for non-trivial numeric relationships.
    sign_total = sign_errors = 0
    if len(numerical) >= 2:
        rr = real[numerical].corr(method="spearman")
        ss = synth[numerical].corr(method="spearman")
        for i in range(len(numerical)):
            for j in range(i + 1, len(numerical)):
                rv, sv = rr.iat[i, j], ss.iat[i, j]
                if np.isfinite(rv) and np.isfinite(sv) and abs(rv) >= 0.10:
                    sign_total += 1
                    sign_errors += int(np.sign(rv) != np.sign(sv))
    return {"score": score, "mean_absolute_association_error": float(np.mean(tri)) if len(tri) else 0.0,
            "numeric_sign_error_rate": sign_errors / sign_total if sign_total else 0.0,
            "pairs_tested": int(len(tri))}


def _resolve_positive(y: pd.Series, positive_label=None):
    values = list(pd.Series(y).dropna().unique())
    if positive_label is not None:
        return positive_label
    if len(values) != 2:
        return None
    # Stable and transparent default: the lexicographically/larger class.
    try:
        return sorted(values)[-1]
    except Exception:
        return values[-1]


def _build_models(categorical: list[str], numerical: list[str], seed: int):
    pre = ColumnTransformer([
        ("num", RobustScaler(), numerical),
        ("cat", OneHotEncoder(handle_unknown="ignore", min_frequency=2), categorical),
    ], remainder="drop")
    return {
        "logistic": Pipeline([("pre", pre), ("model", SGDClassifier(loss="log_loss", max_iter=2000, tol=1e-4, class_weight="balanced", average=True, random_state=seed))]),
        "random_forest": Pipeline([("pre", pre), ("model", RandomForestClassifier(n_estimators=50, min_samples_leaf=2, class_weight="balanced_subsample", n_jobs=1, random_state=seed))]),
    }


def downstream_utility(real_train: pd.DataFrame, real_test: pd.DataFrame, synth: pd.DataFrame,
                       target: str, categorical: list[str], numerical: list[str], seed: int = 42,
                       positive_label=None):
    feature_cat = [c for c in categorical if c != target]
    feature_num = [c for c in numerical if c != target]
    features = feature_num + feature_cat
    y_real = real_train[target]
    y_test = real_test[target]
    y_syn = synth[target]
    positive = _resolve_positive(y_test, positive_label)
    rows = []
    preds = {}
    for name in _build_models(feature_cat, feature_num, seed).keys():
        real_model = _build_models(feature_cat, feature_num, seed)[name]
        syn_model = _build_models(feature_cat, feature_num, seed)[name]
        real_model.fit(real_train[features], y_real)
        syn_model.fit(synth[features], y_syn)
        for source, model in [("real", real_model), ("synthetic", syn_model)]:
            pred = model.predict(real_test[features])
            key = f"{name}_{source}"
            preds[key] = pred
            bal = balanced_accuracy_score(y_test, pred)
            f1 = f1_score(y_test, pred, average="macro")
            auc = np.nan
            if positive is not None and hasattr(model, "predict_proba"):
                classes = list(model.classes_)
                if positive in classes:
                    proba = model.predict_proba(real_test[features])[:, classes.index(positive)]
                    truth = (y_test == positive).astype(int)
                    if truth.nunique() == 2:
                        auc = roc_auc_score(truth, proba)
            rows.append({"model": name, "training_source": source,
                         "balanced_accuracy": float(bal), "macro_f1": float(f1),
                         "roc_auc": float(auc) if np.isfinite(auc) else np.nan})
    frame = pd.DataFrame(rows)
    metric_cols = ["balanced_accuracy", "macro_f1"] + (["roc_auc"] if frame["roc_auc"].notna().any() else [])
    real_mean = frame[frame.training_source == "real"][metric_cols].mean().mean()
    syn_mean = frame[frame.training_source == "synthetic"][metric_cols].mean().mean()
    retention = float(np.clip(syn_mean / max(real_mean, 1e-12), 0, 1))
    return {"score": retention, "real_mean": float(real_mean), "synthetic_mean": float(syn_mean),
            "metrics": frame.to_dict(orient="records"), "predictions": preds, "positive_label": positive}
