from __future__ import annotations
import numpy as np
import pandas as pd


def pareto_frontier(scores: pd.DataFrame, dimensions: list[str]) -> pd.Series:
    values = scores[dimensions].to_numpy(float)
    dominated = np.zeros(len(scores), dtype=bool)
    for i in range(len(scores)):
        for j in range(len(scores)):
            if i == j:
                continue
            if np.all(values[j] >= values[i]) and np.any(values[j] > values[i]):
                dominated[i] = True
                break
    return pd.Series(~dominated, index=scores.index, name="pareto_optimal")


def rank_acceptability(scores: pd.DataFrame, dimensions: list[str], n_draws: int = 100000,
                       seed: int = 42, alpha: float = 1.0):
    x = scores[dimensions].to_numpy(float)
    if np.isnan(x).any():
        raise ValueError("Rank acceptability requires complete dimension scores")
    rng = np.random.default_rng(seed)
    weights = rng.dirichlet(np.full(len(dimensions), alpha), size=n_draws)
    utility = weights @ x.T
    order = np.argsort(-utility, axis=1)
    ranks = np.empty_like(order)
    rows = np.arange(n_draws)[:, None]
    ranks[rows, order] = np.arange(1, len(scores) + 1)
    result = []
    for i, label in enumerate(scores.index):
        rec = {"candidate": label,
               "first_rank_probability": float(np.mean(ranks[:, i] == 1)),
               "expected_rank": float(np.mean(ranks[:, i]))}
        for r in range(1, len(scores) + 1):
            rec[f"rank_{r}_probability"] = float(np.mean(ranks[:, i] == r))
        result.append(rec)
    return pd.DataFrame(result).set_index("candidate")
