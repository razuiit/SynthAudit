from __future__ import annotations
import argparse
import json
from pathlib import Path
import pandas as pd
from .config import AuditConfig
from .audit import audit_many
from .report import save_audit_bundle


def _split(value):
    return [v.strip() for v in value.split(",") if v.strip()] if value else []


def main(argv=None):
    p = argparse.ArgumentParser(prog="synthaudit", description="Audit synthetic tabular data")
    sub = p.add_subparsers(dest="command", required=True)
    a = sub.add_parser("audit")
    a.add_argument("--real-train", required=True)
    a.add_argument("--real-test", required=True)
    a.add_argument("--synthetic", action="append", required=True, help="NAME=path.csv; repeat for multiple candidates")
    a.add_argument("--target", required=True)
    a.add_argument("--protected", default="")
    a.add_argument("--categorical", default="")
    a.add_argument("--numerical", default="")
    a.add_argument("--quasi-identifiers", default="")
    a.add_argument("--positive-label", default=None)
    a.add_argument("--output", required=True)
    a.add_argument("--seed", type=int, default=42)
    args = p.parse_args(argv)
    real_train = pd.read_csv(args.real_train)
    real_test = pd.read_csv(args.real_test)
    synth = {}
    for spec in args.synthetic:
        if "=" not in spec:
            p.error("--synthetic must use NAME=path.csv")
        name, path = spec.split("=", 1)
        synth[name] = pd.read_csv(path)
    cfg = AuditConfig(target=args.target, protected=_split(args.protected),
                      categorical=_split(args.categorical) or None,
                      numerical=_split(args.numerical) or None,
                      quasi_identifiers=_split(args.quasi_identifiers) or None,
                      positive_label=args.positive_label, seed=args.seed)
    bundle = audit_many(real_train, real_test, synth, cfg)
    save_audit_bundle(bundle, args.output)
    print(json.dumps({"output": str(Path(args.output).resolve()),
                      "candidates": list(synth), "dimensions": bundle["dimensions_used"]}, indent=2))

if __name__ == "__main__":
    main()
