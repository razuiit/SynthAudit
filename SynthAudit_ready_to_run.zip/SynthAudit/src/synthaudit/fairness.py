from __future__ import annotations
import numpy as np
import pandas as pd
from sklearn.metrics import balanced_accuracy_score, confusion_matrix


def _binary_truth(series: pd.Series, positive_label):
    return (series == positive_label).astype(int).to_numpy()


def group_metrics(y_true, y_pred, groups: pd.Series, min_group_size: int = 30):
    records = []
    for group, idx in groups.groupby(groups.astype(str)).groups.items():
        idx = np.asarray(list(idx), dtype=int)
        if len(idx) < min_group_size:
            continue
        yt, yp = y_true[idx], y_pred[idx]
        tn, fp, fn, tp = confusion_matrix(yt, yp, labels=[0, 1]).ravel()
        tpr = tp / max(tp + fn, 1)
        fpr = fp / max(fp + tn, 1)
        selection = float(np.mean(yp))
        bal = balanced_accuracy_score(yt, yp) if len(np.unique(yt)) > 1 else np.nan
        records.append({"group": str(group), "n": int(len(idx)), "selection_rate": selection,
                        "tpr": float(tpr), "fpr": float(fpr),
                        "balanced_accuracy": float(bal) if np.isfinite(bal) else np.nan})
    df = pd.DataFrame(records)
    if len(df) < 2:
        return {"demographic_parity_difference": np.nan, "equal_opportunity_difference": np.nan,
                "equalized_odds_difference": np.nan, "worst_group_balanced_accuracy": np.nan,
                "groups": records}
    dp = float(df.selection_rate.max() - df.selection_rate.min())
    eo = float(df.tpr.max() - df.tpr.min())
    eod = float(max(eo, df.fpr.max() - df.fpr.min()))
    wgba = float(df.balanced_accuracy.min())
    return {"demographic_parity_difference": dp, "equal_opportunity_difference": eo,
            "equalized_odds_difference": eod, "worst_group_balanced_accuracy": wgba,
            "groups": records}


def fairness_audit(real_test: pd.DataFrame, target: str, protected: list[str], positive_label,
                   real_predictions: dict, synthetic_predictions: dict, min_group_size: int = 30):
    if positive_label is None or not protected:
        return {"score": np.nan, "attributes": [], "note": "Fairness requires a binary target and protected attributes."}
    y_true = _binary_truth(real_test[target], positive_label)
    attrs = []
    preservation_scores = []
    model_names = sorted(set(real_predictions) & set(synthetic_predictions))
    for attr in protected:
        for model in model_names:
            r_pred = _binary_truth(pd.Series(real_predictions[model]), positive_label)
            s_pred = _binary_truth(pd.Series(synthetic_predictions[model]), positive_label)
            rm = group_metrics(y_true, r_pred, real_test[attr].reset_index(drop=True), min_group_size)
            sm = group_metrics(y_true, s_pred, real_test[attr].reset_index(drop=True), min_group_size)
            drift_terms = []
            for key in ["demographic_parity_difference", "equal_opportunity_difference", "equalized_odds_difference"]:
                if np.isfinite(rm[key]) and np.isfinite(sm[key]):
                    drift_terms.append(abs(sm[key] - rm[key]))
            if np.isfinite(rm["worst_group_balanced_accuracy"]) and np.isfinite(sm["worst_group_balanced_accuracy"]):
                drift_terms.append(max(0.0, rm["worst_group_balanced_accuracy"] - sm["worst_group_balanced_accuracy"]))
            preservation = float(np.clip(1.0 - np.mean(drift_terms), 0, 1)) if drift_terms else np.nan
            if np.isfinite(preservation):
                preservation_scores.append(preservation)
            attrs.append({"protected_attribute": attr, "model": model,
                          "real_trained": rm, "synthetic_trained": sm,
                          "preservation_score": preservation})
    return {"score": float(np.mean(preservation_scores)) if preservation_scores else np.nan,
            "attributes": attrs,
            "note": "Score measures drift from the real-trained reference; raw group metrics remain primary."}
