"""SynthAudit 2.0 public API."""
from .audit import audit_dataset, audit_many
from .config import AuditConfig
from .decision import pareto_frontier, rank_acceptability

__all__ = ["AuditConfig", "audit_dataset", "audit_many", "pareto_frontier", "rank_acceptability"]
__version__ = "2.0.0"
