from __future__ import annotations
from dataclasses import dataclass, field
from typing import Any, Sequence

@dataclass(slots=True)
class AuditConfig:
    """Configuration for one real/synthetic audit.

    No legal-compliance decision is produced. The governance output is an
    evidence card intended to support, not replace, domain and legal review.
    """
    target: str
    protected: Sequence[str] = field(default_factory=tuple)
    categorical: Sequence[str] | None = None
    numerical: Sequence[str] | None = None
    quasi_identifiers: Sequence[str] | None = None
    positive_label: Any | None = None
    seed: int = 42
    max_privacy_rows: int = 1000
    bootstrap_repeats: int = 200
    min_group_size: int = 30

    def validate_columns(self, columns: Sequence[str]) -> None:
        cols = set(columns)
        missing = [c for c in [self.target, *self.protected] if c not in cols]
        if missing:
            raise ValueError(f"Missing required columns: {missing}")
        if self.categorical is not None:
            missing = [c for c in self.categorical if c not in cols]
            if missing:
                raise ValueError(f"Unknown categorical columns: {missing}")
        if self.numerical is not None:
            missing = [c for c in self.numerical if c not in cols]
            if missing:
                raise ValueError(f"Unknown numerical columns: {missing}")
