from __future__ import annotations
import numpy as np
import pandas as pd
from sklearn.metrics import roc_auc_score
from sklearn.neighbors import NearestNeighbors
from .preprocessing import gower_embedding


def exact_match_rate(real_train: pd.DataFrame, synthetic: pd.DataFrame) -> float:
    cols = list(real_train.columns)
    real_hash = pd.util.hash_pandas_object(real_train[cols].astype(str), index=False)
    syn_hash = pd.util.hash_pandas_object(synthetic[cols].astype(str), index=False)
    return float(syn_hash.isin(set(real_hash)).mean())


def membership_inference(real_train: pd.DataFrame, real_test: pd.DataFrame, synthetic: pd.DataFrame,
                         columns: list[str], categorical: list[str], numerical: list[str],
                         seed: int = 42, max_rows: int = 1000, bootstrap_repeats: int = 200):
    rng = np.random.default_rng(seed)
    n = min(max_rows, len(real_train), len(real_test), len(synthetic))
    train = real_train.sample(n=n, random_state=seed)[columns].reset_index(drop=True)
    test = real_test.sample(n=n, random_state=seed + 1)[columns].reset_index(drop=True)
    syn = synthetic.sample(n=n, random_state=seed + 2)[columns].reset_index(drop=True)
    transform, n_orig = gower_embedding([train, test, syn], columns, categorical, numerical)
    x_train, x_test, x_syn = transform(train), transform(test), transform(syn)
    nn = NearestNeighbors(n_neighbors=1, metric="manhattan", algorithm="auto")
    nn.fit(x_syn)
    d_train = nn.kneighbors(x_train, return_distance=True)[0].ravel() / n_orig
    d_test = nn.kneighbors(x_test, return_distance=True)[0].ravel() / n_orig
    labels = np.r_[np.ones(n, dtype=int), np.zeros(n, dtype=int)]
    scores = -np.r_[d_train, d_test]
    auc = float(roc_auc_score(labels, scores))
    advantage = float(max(0.0, 2.0 * (auc - 0.5)))
    boots = []
    for _ in range(max(0, bootstrap_repeats)):
        idx = rng.integers(0, len(labels), len(labels))
        if len(np.unique(labels[idx])) < 2:
            continue
        boots.append(roc_auc_score(labels[idx], scores[idx]))
    if boots:
        low, high = np.quantile(boots, [0.025, 0.975])
    else:
        low = high = auc
    ratio = float(np.median(d_train) / max(np.median(d_test), 1e-12))
    return {"attack_auc": auc, "attack_auc_ci95": [float(low), float(high)],
            "attack_advantage": advantage, "median_train_to_holdout_distance_ratio": ratio,
            "n_members": n, "n_nonmembers": n}


def privacy_audit(real_train: pd.DataFrame, real_test: pd.DataFrame, synthetic: pd.DataFrame,
                  quasi_identifiers: list[str], categorical: list[str], numerical: list[str],
                  seed: int = 42, max_rows: int = 1000, bootstrap_repeats: int = 200):
    qids = [c for c in quasi_identifiers if c in real_train.columns]
    if not qids:
        qids = [c for c in real_train.columns if c in categorical + numerical]
    q_cat = [c for c in qids if c in categorical]
    q_num = [c for c in qids if c in numerical]
    mia = membership_inference(real_train, real_test, synthetic, qids, q_cat, q_num,
                               seed, max_rows, bootstrap_repeats)
    exact = exact_match_rate(real_train, synthetic)
    # A bounded decision-support score. Raw privacy metrics remain primary.
    exact_penalty = min(1.0, exact * 20.0)
    score = float(np.clip(1.0 - max(mia["attack_advantage"], exact_penalty), 0, 1))
    return {"score": score, "exact_match_rate": exact, "membership_inference": mia,
            "score_note": "Decision-support transform; interpret raw attack AUC and exact-match rate first."}
