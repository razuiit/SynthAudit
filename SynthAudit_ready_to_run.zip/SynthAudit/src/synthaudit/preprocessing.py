from __future__ import annotations
import numpy as np
import pandas as pd
from sklearn.preprocessing import OneHotEncoder


def align_frames(real_train: pd.DataFrame, real_test: pd.DataFrame, synthetic: pd.DataFrame):
    cols = list(real_train.columns)
    if set(real_test.columns) != set(cols) or set(synthetic.columns) != set(cols):
        raise ValueError("real_train, real_test, and synthetic must contain the same columns")
    return real_train[cols].copy(), real_test[cols].copy(), synthetic[cols].copy()


def infer_types(df: pd.DataFrame, target: str, categorical=None, numerical=None):
    features = [c for c in df.columns if c != target]
    if categorical is None and numerical is None:
        cat = [c for c in features if (pd.api.types.is_object_dtype(df[c])
                                       or pd.api.types.is_categorical_dtype(df[c])
                                       or pd.api.types.is_bool_dtype(df[c]))]
        num = [c for c in features if c not in cat]
    elif categorical is None:
        num = list(numerical)
        cat = [c for c in features if c not in num]
    elif numerical is None:
        cat = list(categorical)
        num = [c for c in features if c not in cat]
    else:
        cat, num = list(categorical), list(numerical)
    return cat, num


def robust_numeric_scale(series: pd.Series) -> float:
    x = pd.to_numeric(series, errors="coerce").dropna().to_numpy(float)
    if len(x) == 0:
        return 1.0
    q1, q3 = np.quantile(x, [0.25, 0.75])
    scale = float(q3 - q1)
    if not np.isfinite(scale) or scale <= 1e-12:
        scale = float(np.std(x))
    if not np.isfinite(scale) or scale <= 1e-12:
        scale = max(float(np.max(x) - np.min(x)), 1.0)
    return scale


def gower_embedding(frames: list[pd.DataFrame], columns: list[str], categorical: list[str], numerical: list[str]):
    """Create an embedding where Manhattan distance / n_columns is Gower-like.

    Numeric variables are min-max scaled using all supplied reference frames.
    Each categorical one-hot block is multiplied by 0.5, making a mismatch
    contribute exactly one unit of Manhattan distance regardless of cardinality.
    """
    combined = pd.concat([f[columns] for f in frames], ignore_index=True)
    blocks = []
    transforms = []
    if numerical:
        num = combined[numerical].apply(pd.to_numeric, errors="coerce")
        med = num.median()
        num = num.fillna(med)
        lo, hi = num.min(), num.max()
        span = (hi - lo).replace(0, 1.0)
        transforms.append(("num", numerical, med, lo, span))
    if categorical:
        enc = OneHotEncoder(handle_unknown="ignore", sparse_output=False, dtype=np.float32)
        enc.fit(combined[categorical].astype(str).fillna("<NA>"))
        transforms.append(("cat", categorical, enc))

    def transform(frame: pd.DataFrame) -> np.ndarray:
        arrs = []
        for item in transforms:
            if item[0] == "num":
                _, cols, med, lo, span = item
                x = frame[cols].apply(pd.to_numeric, errors="coerce").fillna(med)
                arrs.append(((x - lo) / span).clip(0, 1).to_numpy(np.float32))
            else:
                _, cols, enc = item
                arrs.append(0.5 * enc.transform(frame[cols].astype(str).fillna("<NA>")))
        return np.concatenate(arrs, axis=1) if arrs else np.zeros((len(frame), 0), dtype=np.float32)

    return transform, max(len(columns), 1)
