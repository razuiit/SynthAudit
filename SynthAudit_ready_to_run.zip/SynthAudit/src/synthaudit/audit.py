from __future__ import annotations
import numpy as np
import pandas as pd
from .config import AuditConfig
from .preprocessing import align_frames, infer_types
from .utility import univariate_fidelity, dependency_fidelity, downstream_utility
from .privacy import privacy_audit
from .fairness import fairness_audit
from .governance import evidence_card
from .decision import pareto_frontier, rank_acceptability


def audit_dataset(real_train: pd.DataFrame, real_test: pd.DataFrame, synthetic: pd.DataFrame,
                  config: AuditConfig, metadata: dict | None = None):
    real_train, real_test, synthetic = align_frames(real_train, real_test, synthetic)
    config.validate_columns(real_train.columns)
    categorical, numerical = infer_types(real_train, config.target, config.categorical, config.numerical)
    # Target is treated as categorical for distributional comparisons.
    util_cat = list(dict.fromkeys(categorical + [config.target]))
    util_num = [c for c in numerical if c != config.target]
    univ = univariate_fidelity(real_train, synthetic, util_cat, util_num)
    dep = dependency_fidelity(real_train, synthetic, util_cat, util_num)
    down = downstream_utility(real_train, real_test, synthetic, config.target,
                              categorical, numerical, config.seed, config.positive_label)
    utility_score = float(np.mean([univ["score"], dep["score"], down["score"]]))
    utility = {"score": utility_score, "univariate": univ, "dependency": dep, "downstream": down}
    qids = list(config.quasi_identifiers or [c for c in real_train.columns if c != config.target])
    privacy = privacy_audit(real_train, real_test, synthetic, qids, categorical, numerical,
                            config.seed, config.max_privacy_rows, config.bootstrap_repeats)
    real_preds = {k.replace("_real", ""): v for k, v in down["predictions"].items() if k.endswith("_real")}
    syn_preds = {k.replace("_synthetic", ""): v for k, v in down["predictions"].items() if k.endswith("_synthetic")}
    fairness = fairness_audit(real_test.reset_index(drop=True), config.target, list(config.protected),
                              down["positive_label"], real_preds, syn_preds, config.min_group_size)
    dimensions = {"privacy": privacy["score"], "fidelity": float(np.mean([univ["score"], dep["score"]])),
                  "downstream_utility": down["score"], "fairness": fairness["score"]}
    result = {
        "metadata": metadata or {}, "configuration": config.__dict__ if hasattr(config, "__dict__") else {
            k: getattr(config, k) for k in config.__slots__},
        "types": {"categorical": categorical, "numerical": numerical},
        "dimensions": dimensions, "privacy": privacy, "utility": utility, "fairness": fairness,
    }
    result["governance_evidence_card"] = evidence_card(config, privacy, utility, fairness, metadata)
    # Predictions are useful internally but are removed from serialisable output.
    result["utility"]["downstream"].pop("predictions", None)
    return result


def audit_many(real_train: pd.DataFrame, real_test: pd.DataFrame, synthetic_datasets: dict[str, pd.DataFrame],
               config: AuditConfig, n_weight_draws: int = 100000):
    detailed = {}
    rows = []
    for name, synth in synthetic_datasets.items():
        res = audit_dataset(real_train, real_test, synth, config, {"generator": name})
        detailed[name] = res
        rows.append({"candidate": name, **res["dimensions"]})
    scores = pd.DataFrame(rows).set_index("candidate")
    dims = [c for c in ["privacy", "fidelity", "downstream_utility", "fairness"] if scores[c].notna().all()]
    scores["pareto_optimal"] = pareto_frontier(scores, dims)
    ranks = rank_acceptability(scores, dims, n_draws=n_weight_draws, seed=config.seed)
    return {"scores": scores, "rank_acceptability": ranks, "details": detailed, "dimensions_used": dims}
