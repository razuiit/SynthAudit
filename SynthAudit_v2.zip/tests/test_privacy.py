import pandas as pd
from synthaudit.privacy import exact_match_rate, privacy_audit


def test_exact_match_rate_detects_bootstrap_copying():
    real = pd.DataFrame({"age": [20, 30, 40], "group": ["A", "B", "A"], "y": [0, 1, 0]})
    synth = pd.DataFrame({"age": [20, 30, 99], "group": ["A", "B", "Z"], "y": [0, 1, 1]})
    assert exact_match_rate(real, synth) == 2 / 3


def test_exact_copy_penalty_can_zero_privacy_score():
    real_train = pd.DataFrame({"age": range(40), "group": ["A", "B"] * 20, "y": [0, 1] * 20})
    real_test = pd.DataFrame({"age": range(100, 140), "group": ["A", "B"] * 20, "y": [0, 1] * 20})
    result = privacy_audit(
        real_train,
        real_test,
        real_train.copy(),
        quasi_identifiers=["age", "group"],
        categorical=["group"],
        numerical=["age"],
        seed=2,
        max_rows=30,
        bootstrap_repeats=10,
    )
    assert result["exact_match_rate"] == 1.0
    assert result["score"] == 0.0
