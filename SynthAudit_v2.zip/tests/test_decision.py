import pandas as pd
from synthaudit.decision import pareto_frontier, rank_acceptability


def test_pareto_and_rank_acceptability():
    scores = pd.DataFrame({"a": [0.9, 0.7, 0.4], "b": [0.4, 0.8, 0.3]}, index=["x", "y", "z"])
    front = pareto_frontier(scores, ["a", "b"])
    assert front.to_dict() == {"x": True, "y": True, "z": False}
    ranks = rank_acceptability(scores, ["a", "b"], n_draws=5000, seed=1)
    assert ranks.loc["z", "first_rank_probability"] == 0
    assert abs(ranks["first_rank_probability"].sum() - 1) < 1e-12
