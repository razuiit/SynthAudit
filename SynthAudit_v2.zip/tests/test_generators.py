import sys
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "experiments"))
from generators import generate_dgp, metamorphic_variants


def test_metamorphic_variants_have_expected_schema():
    train = generate_dgp(500, 1)
    variants = metamorphic_variants(train, 400, 2)
    assert set(variants) == {"Ideal DGP", "Memorising", "Independent marginals", "Bias amplified", "Range corrupted", "Mode collapsed"}
    for frame in variants.values():
        assert list(frame.columns) == list(train.columns)
        assert len(frame) == 400


def test_memorising_contains_exact_training_rows():
    train = generate_dgp(500, 1)
    variants = metamorphic_variants(train, 400, 2)
    train_rows = set(map(tuple, train.astype(str).to_numpy()))
    mem_rate = sum(tuple(r) in train_rows for r in variants["Memorising"].astype(str).to_numpy()) / 400
    ideal_rate = sum(tuple(r) in train_rows for r in variants["Ideal DGP"].astype(str).to_numpy()) / 400
    assert mem_rate > 0.6
    assert ideal_rate < 0.05
