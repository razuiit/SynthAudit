import sys
from pathlib import Path
import pandas as pd
ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))
sys.path.insert(0, str(ROOT / "experiments"))
from synthaudit.config import AuditConfig
from synthaudit.audit import audit_many
from generators import generate_dgp, metamorphic_variants


def test_injected_failures_are_detected():
    full = generate_dgp(1600, 20)
    train, test = full.iloc[:1000].reset_index(drop=True), full.iloc[1000:].reset_index(drop=True)
    variants = metamorphic_variants(train, 1000, 30)
    cfg = AuditConfig(target="income", protected=("sex", "race"),
                      categorical=("education", "occupation", "sex", "race"),
                      numerical=("age", "hours", "debt"), positive_label=">50K",
                      quasi_identifiers=("age", "hours", "education", "occupation", "sex", "race"),
                      seed=4, max_privacy_rows=250, bootstrap_repeats=10, min_group_size=20)
    bundle = audit_many(train, test, variants, cfg, n_weight_draws=2000)
    scores = bundle["scores"]
    assert scores.loc["Memorising", "privacy"] < scores.loc["Ideal DGP", "privacy"]
    assert scores.loc["Range corrupted", "fidelity"] < scores.loc["Ideal DGP", "fidelity"]
    assert scores.loc["Independent marginals", "downstream_utility"] < scores.loc["Ideal DGP", "downstream_utility"]
    assert scores.loc["Bias amplified", "fairness"] < scores.loc["Ideal DGP", "fairness"]
