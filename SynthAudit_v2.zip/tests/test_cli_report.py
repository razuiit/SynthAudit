from pathlib import Path
import pandas as pd
from synthaudit.cli import main


def test_cli_writes_complete_bundle(tmp_path: Path):
    train = pd.DataFrame({
        "x": list(range(60)),
        "category": ["A", "B", "C"] * 20,
        "group": ["g1", "g2"] * 30,
        "target": ["no", "yes"] * 30,
    })
    test = pd.DataFrame({
        "x": list(range(100, 140)),
        "category": ["A", "B", "C", "A"] * 10,
        "group": ["g1", "g2"] * 20,
        "target": ["no", "yes"] * 20,
    })
    synth = train.sample(n=len(train), replace=True, random_state=4).reset_index(drop=True)
    train_path, test_path, synth_path = tmp_path / "train.csv", tmp_path / "test.csv", tmp_path / "synth.csv"
    train.to_csv(train_path, index=False)
    test.to_csv(test_path, index=False)
    synth.to_csv(synth_path, index=False)
    output = tmp_path / "audit"
    main([
        "audit",
        "--real-train", str(train_path),
        "--real-test", str(test_path),
        "--synthetic", f"candidate={synth_path}",
        "--target", "target",
        "--protected", "group",
        "--categorical", "category,group",
        "--numerical", "x",
        "--quasi-identifiers", "x,category,group",
        "--positive-label", "yes",
        "--seed", "4",
        "--output", str(output),
    ])
    for name in ["dimension_scores.csv", "rank_acceptability.csv", "audit_details.json", "report.html"]:
        assert (output / name).is_file()
    assert "does not determine legal compliance" in (output / "report.html").read_text(encoding="utf-8")
