from __future__ import annotations
import numpy as np
import pandas as pd
from scipy.stats import norm, rankdata


def independent_marginals(train: pd.DataFrame, n: int, seed: int) -> pd.DataFrame:
    rng = np.random.default_rng(seed)
    return pd.DataFrame({c: rng.choice(train[c].to_numpy(), size=n, replace=True) for c in train.columns})


def conditional_independent(train: pd.DataFrame, target: str, n: int, seed: int) -> pd.DataFrame:
    """Sample each feature independently conditional on the target class.

    The implementation works class-by-class rather than filtering once per row,
    which makes the baseline practical for full benchmark datasets.
    """
    rng = np.random.default_rng(seed)
    target_values = train[target].to_numpy()
    sampled_y = rng.choice(target_values, size=n, replace=True)
    out = pd.DataFrame(index=np.arange(n), columns=train.columns)
    out[target] = sampled_y
    grouped = {y: frame for y, frame in train.groupby(target, dropna=False)}
    for y in pd.unique(sampled_y):
        idx = np.flatnonzero(sampled_y == y)
        pool = grouped.get(y, train)
        for c in train.columns:
            if c == target:
                continue
            out.loc[idx, c] = rng.choice(pool[c].to_numpy(), size=len(idx), replace=True)
    for c in train.columns:
        try:
            out[c] = out[c].astype(train[c].dtype)
        except (TypeError, ValueError):
            pass
    return out[train.columns]


def bootstrap_generator(train: pd.DataFrame, n: int, seed: int) -> pd.DataFrame:
    return train.sample(n=n, replace=True, random_state=seed).reset_index(drop=True)


def _nearest_correlation(matrix: np.ndarray) -> np.ndarray:
    a = (matrix + matrix.T) / 2
    vals, vecs = np.linalg.eigh(a)
    vals = np.clip(vals, 1e-6, None)
    a = vecs @ np.diag(vals) @ vecs.T
    d = np.sqrt(np.diag(a))
    a = a / np.outer(d, d)
    np.fill_diagonal(a, 1.0)
    return a


def gaussian_copula(train: pd.DataFrame, categorical: list[str], n: int, seed: int) -> pd.DataFrame:
    """Small dependency-aware baseline using an empirical Gaussian copula.

    It is intentionally self-contained and is used only as an illustrative
    generator in the software paper, not as a replacement for specialised
    synthetic-data libraries.
    """
    rng = np.random.default_rng(seed)
    latent = []
    specs = {}
    eps = 1e-5
    for c in train.columns:
        x = train[c]
        if c in categorical:
            freq = x.astype(str).value_counts(normalize=True, sort=False)
            cats = list(freq.index)
            probs = freq.to_numpy(float)
            edges = np.r_[0.0, np.cumsum(probs)]
            mids = (edges[:-1] + edges[1:]) / 2
            mapping = dict(zip(cats, mids))
            u = x.astype(str).map(mapping).to_numpy(float)
            specs[c] = ("cat", cats, edges)
        else:
            numeric = pd.to_numeric(x, errors="coerce")
            med = numeric.median()
            numeric = numeric.fillna(med)
            u = rankdata(numeric.to_numpy(float), method="average") / (len(numeric) + 1.0)
            specs[c] = ("num", np.sort(numeric.to_numpy(float)), pd.api.types.is_integer_dtype(x.dtype))
        latent.append(norm.ppf(np.clip(u, eps, 1 - eps)))
    z = np.column_stack(latent)
    corr = _nearest_correlation(np.corrcoef(z, rowvar=False))
    sampled = rng.multivariate_normal(np.zeros(len(train.columns)), corr, size=n)
    out = {}
    for j, c in enumerate(train.columns):
        u = norm.cdf(sampled[:, j])
        spec = specs[c]
        if spec[0] == "cat":
            _, cats, edges = spec
            idx = np.searchsorted(edges[1:], u, side="right")
            idx = np.clip(idx, 0, len(cats) - 1)
            out[c] = np.asarray(cats, dtype=object)[idx]
        else:
            _, sorted_values, was_int = spec
            q = np.clip((u * (len(sorted_values) - 1)).astype(int), 0, len(sorted_values) - 1)
            vals = sorted_values[q]
            out[c] = np.rint(vals).astype(int) if was_int else vals
    return pd.DataFrame(out)[train.columns]


def generate_dgp(n: int, seed: int) -> pd.DataFrame:
    rng = np.random.default_rng(seed)
    sex = rng.choice(["Female", "Male"], size=n, p=[0.48, 0.52])
    race = rng.choice(["Minority", "Majority"], size=n, p=[0.28, 0.72])
    female = (sex == "Female").astype(float)
    minority = (race == "Minority").astype(float)
    age = np.clip(rng.normal(39 + 1.5 * minority, 11, n), 18, 75)
    education_latent = rng.normal(0.3 - 0.25 * minority + 0.08 * (age - 39) / 11, 1, n)
    education = np.where(education_latent > 0.85, "Graduate",
                 np.where(education_latent > -0.45, "College", "School"))
    edu_num = pd.Series(education).map({"School": 0, "College": 1, "Graduate": 2}).to_numpy()
    occupation = np.where(edu_num == 2, rng.choice(["Professional", "Manager"], n),
                 np.where(edu_num == 1, rng.choice(["Clerical", "Technical", "Service"], n),
                          rng.choice(["Manual", "Service"], n)))
    hours = np.clip(rng.normal(38 + 3 * edu_num - 1.5 * female, 8, n), 5, 75)
    debt = np.exp(rng.normal(8.2 - 0.25 * edu_num + 0.15 * minority, 0.65, n))
    logit = (-1.7 + 0.045 * (age - 35) + 0.72 * edu_num + 0.025 * (hours - 35)
             - 0.000025 * debt - 0.32 * female - 0.42 * minority
             + rng.normal(0, 0.45, n))
    prob = 1 / (1 + np.exp(-logit))
    income = np.where(rng.random(n) < prob, ">50K", "<=50K")
    return pd.DataFrame({"age": np.rint(age).astype(int), "hours": np.rint(hours).astype(int),
                         "debt": np.round(debt, 2), "education": education,
                         "occupation": occupation, "sex": sex, "race": race, "income": income})


def metamorphic_variants(train: pd.DataFrame, n: int, seed: int) -> dict[str, pd.DataFrame]:
    rng = np.random.default_rng(seed)
    ideal = generate_dgp(n, seed + 1000)
    memorising = pd.concat([
        train.sample(n=int(0.8 * n), replace=True, random_state=seed + 1),
        generate_dgp(n - int(0.8 * n), seed + 2)
    ], ignore_index=True).sample(frac=1, random_state=seed).reset_index(drop=True)
    marginal = independent_marginals(train, n, seed + 3)
    biased = generate_dgp(n, seed + 4)
    mask = ((biased["sex"] == "Female") | (biased["race"] == "Minority")) & (biased["income"] == ">50K")
    flip = mask & (rng.random(n) < 0.70)
    biased.loc[flip, "income"] = "<=50K"
    corrupted = generate_dgp(n, seed + 5)
    idx = rng.choice(n, size=max(1, int(0.12 * n)), replace=False)
    corrupted.loc[idx, "age"] = corrupted.loc[idx, "age"] + rng.integers(45, 90, len(idx))
    corrupted.loc[idx, "hours"] = corrupted.loc[idx, "hours"] + rng.integers(50, 120, len(idx))
    corrupted.loc[idx, "debt"] = corrupted.loc[idx, "debt"] * rng.uniform(6, 20, len(idx))
    collapsed = generate_dgp(n, seed + 6)
    collapse_idx = rng.random(n) < 0.75
    collapsed.loc[collapse_idx, "education"] = "College"
    collapsed.loc[collapse_idx, "occupation"] = "Service"
    return {"Ideal DGP": ideal, "Memorising": memorising, "Independent marginals": marginal,
            "Bias amplified": biased, "Range corrupted": corrupted, "Mode collapsed": collapsed}
