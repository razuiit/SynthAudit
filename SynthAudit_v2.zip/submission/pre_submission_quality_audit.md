# Pre-submission quality audit

## Venue decision

**Selected venue:** SoftwareX.

Reason: the revised contribution is now primarily reusable, open-source research software with a concise descriptive paper, formal validation, tests, documentation, and a reproducible distribution. This is a safer and more defensible route than retaining the original paper as a broad legal/privacy/fairness research article.

## High-risk issues in the original manuscript that were removed

- Fixed universal weights and unsupported GOOD/MODERATE thresholds.
- A numerical “legal compliance” score and language implying legal determination.
- Privacy claims based on incomplete or incorrectly interpreted proxies.
- Unnormalised numerical distances that were not comparable across columns.
- Overstatement of new metrics already represented in existing packages.
- Generator-level fairness conclusions supported primarily by one benchmark.
- Correlations and rank claims based on very small samples.
- Inconsistency between the training-progression figure and table.
- An eight-page research argument with too little methodological detail and literature coverage.

## What now supports reviewability

- Formal, inspectable definitions for every dimension.
- Raw attack evidence and bootstrap confidence intervals.
- Independent holdout requirement and train-synthetic/test-real validation.
- Fairness drift relative to an explicit real-trained reference.
- Pareto analysis rather than a universal aggregate score.
- Stochastic rank acceptability across 100,000 uncertain weight vectors.
- Twelve replicated metamorphic experiments with known injected failures.
- Every injected failure has its largest mean loss in the intended dimension.
- A reproducible real-data case study showing why privacy cannot be inferred from fidelity or utility.
- Ten automated tests, including tests of frozen publication claims.
- Installable wheel, CLI, HTML report, API notes, environment record, and full reproduction script.
- Manuscript below the SoftwareX 4,000-word limit.

## Residual reviewer risks

1. Privacy coverage is deliberately narrow: one nearest-neighbour membership attack plus exact matches. The manuscript states this clearly and treats expansion as future work.
2. Adult is an illustrative benchmark with known limitations. Claims are restricted accordingly.
3. The bounded dimension transforms are decision aids, not calibrated universal thresholds. Raw metrics remain primary.
4. The public repository and archival DOI do not yet exist. They must be created from the exact release archive and inserted before submission.
5. Author contributions, conflict statement, AI declaration, and dataset redistribution must be confirmed by the authors.

## Validation completed in this package

- `pytest -q`: 10 tests passed.
- Editable installation and command-line entry point: passed.
- Python wheel build without build isolation: passed.
- Main manuscript: compiled to 12 pages and visually inspected page by page.
- Supplementary Methods: compiled to 5 pages and visually inspected.
- Cover letter: compiled to 1 page and visually inspected.
- Main-paper word count: 2,261 including headers and captions; below the 4,000-word limit.
