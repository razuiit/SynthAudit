# Verification report - SynthAudit 2.0.0

Verification date: 3 August 2026

## Executed checks

- Re-ran all 12 metamorphic replicates and regenerated aggregate tables and figures.
- Re-ran all four UCI Adult candidates in isolated processes and regenerated aggregate outputs.
- Ran the automated test suite after regeneration: **10 tests passed**.
- Recompiled the SoftwareX manuscript: **12 pages**.
- Recompiled Supplementary Methods: **5 pages**.
- Recompiled the cover letter: **1 page**.
- Rendered and visually inspected the manuscript, supplement, and cover letter for clipping, broken glyphs, and figure/table layout.

## Frozen headline results

- Controlled-failure selectivity: privacy loss 0.965 for memorisation; downstream-utility loss 0.231 for independent marginals; fairness loss 0.162 for bias amplification; fidelity losses 0.143 and 0.068 for range corruption and mode collapse.
- Mean first-rank probability across metamorphic replicates: ideal sample 0.667; mode collapse 0.194; range corruption 0.116; bias amplification 0.013; memorisation 0.010.
- UCI Adult first-rank probability over 100,000 weight draws: empirical Gaussian copula 0.692; conditional marginals 0.199; bootstrap memoriser 0.109; independent marginals 0.000.

## Remaining author-controlled actions

- Create a public repository and archive the exact v2.0.0 release.
- Replace repository/DOI placeholders everywhere before submission.
- Confirm author order, affiliations, CRediT roles, competing-interest statement, and AI-use declaration.
