# Author checks required before submission

The research package is technically complete, but the following statements cannot be decided on behalf of the authors:

- Confirm author order, spelling, affiliations, and corresponding author.
- Confirm that both listed authors satisfy the journal's authorship criteria.
- Confirm or amend the CRediT roles in the manuscript.
- Confirm the declaration of competing interest.
- Amend the generative-AI declaration so it exactly matches actual use.
- Run the exact archived release once on a clean machine or fresh environment.
- Create a public version-controlled repository and archival release.
- Insert the final repository URL and Zenodo DOI in the manuscript, README, `CITATION.cff`, and metadata.
- Check redistribution permissions for every dataset retained in the public archive.
- Review every citation against the source and perform a final proofread.
