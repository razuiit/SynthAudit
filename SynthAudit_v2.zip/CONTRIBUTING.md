# Contributing

Contributions are welcome through issues and pull requests once the repository URL is public.

A contribution should:

1. Add or update tests for every metric or behavioural change.
2. Preserve raw diagnostic outputs; do not replace evidence with a single unexplained score.
3. State the threat model and limitations for privacy diagnostics.
4. Avoid legal-compliance, anonymity, or fairness-certification claims.
5. Run `pytest -q` and the relevant experiment before submission.
6. Document any change that affects published results in `CHANGELOG.md`.

For a new metric, include a formal definition, boundedness and direction, treatment of missing values, a synthetic counterexample, and at least one metamorphic test showing the failure it is intended to detect.
