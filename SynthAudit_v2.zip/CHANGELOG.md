# Changelog

## 2.0.0 — 2026-08-03

This is a methodological redesign rather than a cosmetic revision.

### Added
- Nearest-synthetic membership-inference AUC with bootstrap confidence intervals.
- Exact training-record match detection.
- Scale-normalised numerical fidelity, categorical total-variation similarity, and mixed-type association fidelity.
- Train-synthetic/test-real utility relative to a real-trained reference across two model families.
- Fairness-preservation analysis relative to a real-trained reference, including group-level raw metrics.
- Pareto-front analysis and stochastic rank acceptability over uncertain stakeholder weights.
- Governance evidence cards that record assumptions, raw evidence, and interpretation limitations.
- Metamorphic validation with five controlled failure modes and 12 replicates.
- Reproducible UCI Adult case study, tests, frozen outputs, figures, and SoftwareX manuscript.

### Removed or changed
- Removed the fixed legal-compliance score and all claims that software can determine legal compliance.
- Removed the fixed universal weighted score and arbitrary pass/fail labels.
- Replaced unnormalised distribution distances and undocumented aggregate rules.
- Reframed fairness as preservation/drift relative to an explicit real-trained reference.
- Limited claims to evidence supported by the experiments.
