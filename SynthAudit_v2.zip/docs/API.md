# SynthAudit API notes

## Core entry points

### `AuditConfig`

```python
from synthaudit import AuditConfig

config = AuditConfig(
    target="income",
    protected=["sex", "race"],
    categorical=[...],
    numerical=[...],
    quasi_identifiers=[...],
    positive_label=">50K",
    seed=42,
)
```

The real training, real holdout, and synthetic frames must have the same columns. The real holdout must not have been used to fit the generator.

### `audit_dataset`

```python
from synthaudit import audit_dataset
result = audit_dataset(real_train, real_test, synthetic, config)
```

Returns raw and bounded diagnostics for one synthetic candidate plus a governance evidence card.

### `audit_many`

```python
from synthaudit import audit_many
bundle = audit_many(
    real_train,
    real_test,
    {"Generator A": synth_a, "Generator B": synth_b},
    config,
    n_weight_draws=100_000,
)
```

Returns candidate dimension scores, Pareto status, stochastic rank acceptability, and detailed raw evidence.

### `save_audit_bundle`

```python
from synthaudit.report import save_audit_bundle
save_audit_bundle(bundle, "audit_output")
```

Writes:
- `dimension_scores.csv`
- `rank_acceptability.csv`
- `audit_details.json`
- `report.html`

## Interpretation contract

- Privacy outputs are empirical attack evidence, not a proof of anonymity or differential privacy.
- Fidelity is a collection of distribution and association summaries, not causal validation.
- Downstream utility is conditional on the supplied task, models, metrics, and holdout.
- Fairness preservation is drift from the real-trained reference, not a declaration that either model is fair.
- Rank acceptability describes sensitivity to priorities; it does not identify a universal best generator.
